#!/usr/bin/env bash
# npm install -g gulp webpack
# npm i
# gulp
set -e
echo "start build >> "

git pull origin master
git submodule foreach git pull origin master

if ! command -v npm >/dev/null 2>&1 ; then
    if ! command -v yum >/dev/null 2>&1 ; then
        yum install nodejs
    fi

    if ! command -v apt-get >/dev/null 2>&1 ; then
        apt-get install nodejs
    fi
fi

cnpm i

npm run build

if [ ! -d "/medishare/app/dev_static/ant" ]; then
    mkdir -p /medishare/app/dev_static/swift
fi
cp -r ./dist/* /medishare/app/dev_static/swift
echo -e "\e[32m<< Success! "
