var Mock = require('mockjs');

var data = function() {
    return Mock.mock({
        "code": 0,
        "data": {
            "timeStamp": "1484453414",
            "nonceStr": "42fc9b9a84f6353ea868e986a9dcab07",
            "extendPackage": "prepay_id=wx20170115120954175651b6890067831362",
            "signType": "MD5",
            "paySign": "B702D6AF274B08E47477BD994F029FB2",
            "hasPay": true
        }
    })
}
module.exports = data;