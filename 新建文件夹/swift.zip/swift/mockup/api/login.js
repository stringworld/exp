var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [{}]
    })
}
module.exports = data;