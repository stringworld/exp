var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "data": {
            "departmentList": [{
                    "name": "内科",
                    "id": "652"
                },
                {
                    "name": "外科",
                    "id": "653"
                },
                {
                    "name": "妇产科",
                    "id": "654"
                },
                {
                    "name": "儿科",
                    "id": "655"
                },
                {
                    "name": "中西医结合科",
                    "id": "656"
                }
            ],
            "departmentType": "-1"
        },
        "type": "DepartmentInfo"
    });
};
module.exports = data;