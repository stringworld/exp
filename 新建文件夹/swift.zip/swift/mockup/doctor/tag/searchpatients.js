var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "code": 0,
        "data": {
            "patientList": [{
                    "id": "100022",
                    "memberId": "com.medishare.manis.domain.member.Patient_100022",
                    "portrait": "http://192.168.10.213:8082/img/3c629b7c-96be-42b7-aea8-fef2dba64b84.png",
                    "username": "18198885512",
                    "realname": "哦实验室",
                    "gender": "男",
                    "birthday": 1449417600000,
                    "address": "上海上海市虹口区曲阳路街道玉一居委会",
                    "nickname": "tommy",
                    "provinceId": "2",
                    "cityId": "75",
                    "districtId": "783",
                    "townId": "5558",
                    "communityId": "2593",
                    "inService": false,
                    "created": 1449369914000,
                    "updated": 1450340293000,
                    "tags": [
                        "高血压",
                        "帕金森",
                        "高血压1",
                        "失能",
                        "天下"
                    ],
                    "pushKey": "5ecfaec8b505eb8a074bfc948bb4b025fec82b18"
                },
                {
                    "id": "100014",
                    "memberId": "com.medishare.manis.domain.member.Patient_100014",
                    "portrait": "http://192.168.10.215/images/footer_logo.png",
                    "username": "13511111114",
                    "realname": "真名",
                    "gender": "男",
                    "birthday": 1447143715000,
                    "phone": "13511111114",
                    "address": "地址1",
                    "nickname": "tommy",
                    "provinceId": "3",
                    "cityId": "3",
                    "districtId": "2",
                    "townId": "2",
                    "inService": false,
                    "created": 1448971104000,
                    "updated": 1449136616000,
                    "tags": [
                        "高血压",
                        "脑出血",
                        "冠心病",
                        "糖尿病医院",
                        "心脏病123",
                        "帕金森",
                        "1234565567",
                        "脑中风",
                        "高血压1",
                        "老年痴呆",
                        "失能",
                        "123456556",
                        "天下"
                    ],
                    "pushKey": "058e50b89af382d41b7b7fe1980cb1025f926a18"
                }
            ],
            "addTagUrl": "http://192.168.10.36:8080/prm.html#/addLabel"
        },
        "pager": {
            "current": 0,
            "pageSize": 0,
            "hasNext": false,
            "count": 0
        }
    })
}
module.exports = data;