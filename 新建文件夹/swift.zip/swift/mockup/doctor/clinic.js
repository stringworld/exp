var Mock = require('mockjs');
var data = function() {
	return Mock.mock({
		"code": 0,
		"data": {
			"address": "上海市辖区黄浦区南京东路街道社区卫生服务中心",
			"award": "测试内容hua2",
			"doctorType": "全科",
			"educationInfo": "测试内容x47t",
			"memberId": "com.medishare.manis.domain.member.Doctor_100369",
			"name": "周勇",
			"portrait": "http://192.168.10.215:8082/img/81446eba-3acf-414f-b87b-9f6f68988809.jpg",
			"scienceFruit": "测试内容2q4t",
			"societyDuty": "测试内容1qos",
			"specialtyList": [
				"阴道炎",
				"宫颈炎",
				"盆腔炎",
				"妇科月经病"
			],
			"study": "测试内容cw6f",
			"title": "主治医师",
			"workExperience": "测试内容w50s"
		},
		"errorMsg": 1,
		"pager": 1,
		"serialID": 1
	})
}
module.exports = data;