var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": {
            "couponList": [
                {
                    "amt": {
                        "amount": 9000
                    },
                    "accountId": "acc_100080_com.medishare.manis.domain.member.Patient",
                    "amtDesc": "￥9,000",
                    "disabled": false,
                    "discount": "1.0",
                    "expiration": "2015/12/12 ~ 2017/12/20",
                    "fromDate": 1449893532000,
                    "id": "105028",
                    "isDeducted": false,
                    "memo": "描述",
                    "title": "SQL添加红包",
                    "utilDate": 1513699200000
                },
                {
                    "amt": {
                        "amount": 9000
                    },
                    "accountId": "acc_100080_com.medishare.manis.domain.member.Patient",
                    "amtDesc": "￥9,000",
                    "disabled": false,
                    "discount": "1.0",
                    "expiration": "2015/12/12 ~ 2017/12/20",
                    "fromDate": 1449893532000,
                    "id": "105029",
                    "isDeducted": false,
                    "memo": "描述",
                    "title": "SQL添加红包",
                    "utilDate": 1513699200000
                }
            ]
        },
        "pager": {
            "count": 0,
            "current": 0,
            "hasNext": true,
            "pageSize": 0
        }
    })
}
module.exports = data;