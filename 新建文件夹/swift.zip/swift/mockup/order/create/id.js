var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        code: 0,
        data: {
            "url": "http://192.168.10.215:8082/img/73626350-67a7-4a5f-9ccd-fc7429d13207.jpeg"
        }
    })
}
module.exports = data;
