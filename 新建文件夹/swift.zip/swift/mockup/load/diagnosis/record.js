var Mock = require('mockjs');
var data = function() {
    return Mock.mock({        
        "code":0,
        "data":{
            "id":"1",
            "description":"圣诞节佛山的房价上地方就是独守空房聚少离多放假了上岛咖啡的看法加拉sd卡尖峰时刻",
            "caseLabelList":[],
            "orderId":"103693"
        }        
    });
}
module.exports = data;