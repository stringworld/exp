var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        code: 0,
        data: {
            name: '上门服务',
            serviceContent: '32321321412312312312312313',
            applicablePeopleList: [
                '213123',
                '3123123',
                '31241423'
            ],
            needingAttentionList: [
                '3234234234',
                '324423432'
            ]
        }
    });
};
module.exports = data;