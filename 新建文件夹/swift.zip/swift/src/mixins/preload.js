/**
 * Created by zhouhua on 2017/1/12.
 */
import u from 'underscore';
import bus from 'src/event';
function processing(datasource){
    debugger;
     if(u.isObject(datasource)){
         const promises = [];
         Object.keys(datasource).forEach(key => {
             const item = datasource[key];
             if(item.then){
                 promises.push(item.then((data) => {
                     debugger;
                     this.$set(datasource, key, data);
                 }))
             }else{
                 promises.push(processing.call(this, item));
             }
         });
         return Promise.all(promises);
     }
}
export default {
    created(){
        if(this.datasource){
            bus.$emit('indicatorShow');
            processing.call(this, this.datasource).then(() => {
                    bus.$emit('indicatorHide');
                }
            )
        }
    }
}
