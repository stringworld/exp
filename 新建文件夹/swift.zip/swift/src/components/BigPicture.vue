<template>
    <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
        <div v-show="isShow" class="mask" @click.self="hide">
            <div class="wrapper">
                <img :src="src"
                     v-finger:single-tap="hide"
                     v-finger:double-tap="toggle"
                     :style="'height:'+height+'px; width='+width+'px;'"/>
            </div>
            <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
                <p class="hint" v-show="!isBig"><span class="content">双击图片放大</span></p>
            </transition>
        </div>
    </transition>
</template>
<style lang="less" scoped rel="stylesheet/less">
    .mask {
        position: fixed;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background: rgba(0,0,0,.8);
    }

    .wrapper {
        overflow: auto;
        max-width: 100%;
        max-height: 100%;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate3D(-50%, -50%, 0);
        img {
            transition: all .2s;
        }
    }

    .hint {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        text-align: center;
        padding: 10px;
        .content {
            display: inline-block;
            color: #aaa;
            font-size: 14px;
            text-shadow: 1px 1px rgba(0, 0, 0, 0.2);
        }
    }
</style>
<script type="text/javascript">
    import bus, {on} from 'src/event';
    export default{
        data(){
            return {
                src: '',
                fitHeight: 0,
                fitWidth: 0,
                bigHeight: 0,
                bigWidth: 0,
                isBig: false,
                isShow: false
            }
        },
        computed: {
            height(){
                return this.isBig ? this.bigHeight : this.fitHeight;
            },
            width(){
                return this.isBig ? this.bigWidth : this.fitWidth;
            }
        },
        created(){
            const w = window.innerWidth;
            const h = window.innerHeight;
            const r = w / h;
            bus.$on('showBigPicture', ({src, height, width}) => {
                this.src = src;
                const ratio = width / height;
                if (ratio >= r) {
                    this.fitWidth = Math.min(w, width);
                    this.fitHeight = this.fitWidth / ratio;
                    this.bigHeight = h;
                    this.bigWidth = h * ratio;
                }
                else {
                    this.fitHeight = Math.min(h, height);
                    this.fitWidth = this.fitHeight * ratio;
                    this.bigWidth = w;
                    this.bigHeight = w / ratio;
                }
                this.isShow = true;
            });
        },
        methods: {
            hide(){
                this.isShow = false;
                this.isBig = false;
                this.fitHeight = 0;
                this.fitHeight = 0;
                this.bigHeight = 0;
                this.bigWidth = 0;
            },
            toggle(){
                this.isBig = !this.isBig;
            }
        }
    }
</script>
