<template>
    <div class="tab-container">
        <ul class="tab-title-container">
            <li class="tab-title" v-for="(item,index) in datasource" :class="{'active': item.value === current}" :key="index" @click="setCurrent(item.value)">{{item.text}}</li>
        </ul>
    </div>
</template>

<script type="text/babel">
    export default {
        props: {
            datasource: {
                type: Array,
                default: []
            },
            current: {
                type: String
            }
        },
        methods: {
            setCurrent(current) {
                this.$emit('change',current);
            }
        }
    };
</script>

<style lang="less" scoped rel="stylesheet/css">
    .tab-container {
       width: 100%;
   }
   
    ::-webkit-scrollbar {
       width: 0px;
   }
   
   .tab-title-container {
       position: relative;
       margin: 0 auto;
       list-style: none;
       border-bottom: 1px solid rgba(221, 221, 221, 0.58);
       display: -webkit-box;
       display: -moz-box;
       display: -o-box;
       display: -ms-flexbox;
       display: flex;
       flex-wrap: nowrap;
       align-items: center;
       justify-content: center;
       width: 100%;
   }
   
   .tab-title {
       height: 50px;
       line-height: 50px;
       position: relative;
       text-align: center;
       cursor: pointer;
       outline-style: none;
       -webkit-box-flex: 1;
       -webkit-flex: 1;
       -ms-flex: 1;
       flex: 1;
       font-size: 16px;
       &:after {
           content: "";
           position: absolute;
           top: 50%;
           right: 0;
           transform: translate(-50%, -50%);
           width: 1px;
           height: 25px;
           background-color: rgba(221, 221, 221, 0.58);
       }
       &:last-child:after {
           content: "";
           width: 0;
           height: 0;
       }
   }
   
   .tab-title.active,
   .tab-title:active {
       -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
       font-size: 16px;
       color: #BE3468;
       border-bottom: 2px solid #BE3468;
   }
</style>