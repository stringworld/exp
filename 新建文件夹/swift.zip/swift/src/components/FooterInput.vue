<template>
    <footer :class="{fixed: isAndroid}">
        <div class=input-panel ref="inputPanel">
            <button class="btn round-btn record-btn left-btn" @click.stop="openRecord"></button>
            <textarea ref="textarea" rows="1" v-model.trim="msg" @focus="focus" @blur="blur"></textarea>
            <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
                <button class="btn plain-btn primary-btn right-btn" key="1" v-if="hasContent" @click="send">发送
                </button>
                <button class="btn round-btn add-btn right-btn" key="2" v-else @click="add"></button>
            </transition>
        </div>
        <div class="voice-panel" :class="{holding: beHolding, show: showVoicePanel}">
            <button v-finger:touch-start="startRecord"
                    v-finger:touch-end="endRecord"
                    v-finger:touch-cancel="endRecord"></button>
            <p>按住说话</p>
        </div>
    </footer>
</template>
<style lang="less" scoped rel="stylesheet/less">
    footer {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        background: #F8F7FA;
        &.fixed {
            position: fixed;
        }
        button {
            -webkit-touch-callout: none;
            user-select: none;
        }
        .input-panel {
            padding: 8px 52px;
            background: #fff;
            position: relative;
        }
        textarea {
            min-height: 32px;
            max-height: 112px;
            line-height: 20px;
            background: #F4F3F5;
            font-size: 16px;
            border-radius: 4px;
            padding: 6px 8px;
            border: none;
            width: 100%;
            color: #52525C;
            resize: none;
            vertical-align: bottom;
            transition: all .2s ease;
        }
        .btn {
            position: absolute;
            bottom: 8px;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border: none;
            padding: 0;
            background: #fff;
            font-size: 16px;
            color: #BE3468;
            &.left-btn {
                left: 10px;
            }
            &.right-btn {
                right: 10px;
            }
            &.record-btn {
                background: url(../assets/img/icon_voice.png);
                background-size: cover;
            }
            &.add-btn {
                background: #fff url(../assets/img/icon_plus.png);
                background-size: cover;
            }
        }
        .voice-panel {
            height: 0;
            overflow: hidden;
            transform: translate3d(0, 0, 0);
            transition: all .2s;
            button {
                width: 80px;
                height: 80px;
                border-radius: 40px;
                display: block;
                margin: 30px auto 0 auto;
                background: url(../assets/img/btn_voice_default.png);
                background-size: cover;
                transition: all .2s;
            }
            p {
                margin-top: 10px;
                font-size: 14px;
                line-height: 20px;
                color: #83838F;
                text-align: center;
            }
            &.holding {
                button {
                    background: url(../assets/img/btn_voice_active.png);
                    background-size: cover;
                }
            }
            &.show {
                height: 160px;
            }
        }
    }
</style>
<script type="text/javascript">
    import autosize from 'autosize';
    import config from 'src/config';
    import bus from 'src/event';
    import u from 'underscore';
    const MessageType = config.MessageType;
    const ua = navigator.userAgent;
    export default{
        data(){
            return {
                msg: '',
                beHolding: false,
                showVoicePanel: false,
                recordStartTime: 0,
                isAndroid: ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1
            }
        },
        computed: {
            hasContent(){
                return !!this.msg;
            }
        },
        mounted(){
            autosize(this.$refs.textarea);
            wx.onVoiceRecordEnd({
                complete: ({localId}) => {
                    this.handleRecord(localId);
                }
            })
        },
        watch: {
            showVoicePanel(val){
                bus.$emit('changePaddingBottom', (val ? 160 : 0) + this.$refs.inputPanel.clientHeight);
            }
        },
        methods: {
            send(){
                this.showVoicePanel = false;
                if (this.msg) {
                    this.$emit('send', this.buildMessage(this.msg, MessageType.text));
                    this.msg = '';
                    this.$nextTick(() => autosize.update(this.$refs.textarea));
                }
            },
            openRecord(){
                this.showVoicePanel = !this.showVoicePanel;

            },
            startRecord(e){
                wx.stopRecord();
                this.beHolding = true;
                this.recordStartTime = +new Date;
                wx.startRecord();
                setTimeout(() => this.endRecord(), 60000);
                e.preventDefault();
            },
            endRecord(){
                if (this.recordStartTime) {
                    wx.stopRecord({
                        success: ({localId}) => {
                            this.handleRecord(localId);
                        }
                    });
                }
            },
            handleRecord(localId){
                const now = +new Date;
                if (now - this.recordStartTime < 800) {
                    this.$toast('录音时间太短');
                }
                else {
                    wx.translateVoice({
                        localId,
                        isShowProgressTips: 1,
                        success: ({translateResult}) => {
                            if (translateResult) {
                                this.msg += translateResult;
                                this.$nextTick(() => autosize.update(this.$refs.textarea));
                            }
                            else {
                                this.$toast('识别失败');
                            }

                        }
                    });
                }
                this.recordStartTime = 0;
                this.beHolding = false;
            },
            add(){
                const self = this;
                this.showVoicePanel = false;
                wx.chooseImage({
                    count: 1,
                    success({localIds}){
                        const localId = localIds[0];
                        wx.uploadImage({
                            localId,
                            isShowProgressTips: 1,
                            success: function ({serverId}) {
                                self.$http.get(config.apis.uploadWxImage, {params: {mediaId: serverId}})
                                    .then(({data}) => {
                                        if (data.code) {
                                            self.$toast('图片上传失败!');
                                        }
                                        else {
                                            console.log(data.data);
                                            self.$emit('send', self.buildMessage(data.data.url, MessageType.image));
                                        }
                                    });
                            }
                        });
                    }
                });
            },
            focus(){
                this.showVoicePanel = false;
                this.timer = setInterval(function () {
                    document.body.scrollTop = document.body.scrollHeight;
                }, 100);
            },
            blur(){
                this.showVoicePanel = false;
                if (this.timer) {
                    clearInterval(this.timer);
                }
            },
            buildMessage(content, type){
                const msg = {type};
                switch (type) {
                    case MessageType.text: {
                        msg.content = content;
                        break;
                    }
                    case MessageType.image: {
                        msg.attach = content;
                        break;
                    }
                    default:
                        break;
                }
                return msg;
            }
        },
        beforeDestroy(){
            if (this.timer) {
                clearInterval(this.timer);
            }
            this.recordStartTime && wx.stopRecord();
        }
    }
</script>
