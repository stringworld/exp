<template>
    <section class="order-steps" v-bind:class="step">
        <ul>
            <li>
                <i></i>
                <span>确认</span>
            </li>
            <li>
                <i></i>
                <span>支付</span>
            </li>
            <li>
                <i></i>
                <span>服务</span>
            </li>
            <li>
                <i></i>
                <span>完成</span>
            </li>
        </ul>
    </section>
</template>
<style scoped lang="less">
    .order-steps {
        .before-step{
            &:before {
                background: #E67399;
            }
            i {
                background: #E67399;
            }
            span {
                color: #E67399;
            }
        }
        .now-step{
            &:before {
                background: #E67399;
            }
            i {
                background: #be3468;
            }
            span {
                color: #be3468;
            }
        }
        &.step-confirm {
            li:nth-child(-n+1) {
                .now-step;
            }
        }
        &.step-pay {
            li:nth-child(-n+1) {
                .before-step;
            }
            li:nth-child(2){
                .now-step;
            }
        }
        &.step-service {
            li:nth-child(-n+2) {
                .before-step;
            }
            li:nth-child(3){
                .now-step;
            }
        }
        &.step-finish {
            li:nth-child(-n+3) {
                .before-step;
            }
            li:nth-child(4){
                .now-step;
            }
        }
        ul {
            text-align: center;
            padding: 15px 0 5px 0px;
        }
        li {
            span {
                color: #ceced9;
            }
            &:before {
                content: " ";
                width: 100%;
                height: 2px;
                background: #ebebf0;
                position: absolute;
                left: -50%;
                margin-left: 2px;
                top: 7px;
            }
            &:first-child {
                &:before {
                    display: none;
                }
            }
            i {
                position: relative;
                width: 16px;
                height: 16px;
                border: 4px solid #f8f7fa;
                border-radius: 50%;
                background: #ceced9;
                display: block;
                margin: 0 auto;
                z-index: 1;
            }
            position:relative;
            display:inline-block;
            width: 24%;
            text-align:center;
        }
    }

</style>
<script>
    export default {
        props: ['step']
    }

</script>