<template>
    <audio ref="audio" :src="src" autoplay></audio>
</template>
<style lang="less" scoped rel="stylesheet/less">
    audio {
        display: none;
    }
</style>
<script type="text/javascript">
    import bus, {on} from 'src/event';
    import config from 'src/config';
    import u from 'underscore';
    export default{
        data(){
            return {
                src: null,
                uid: '',
                isPlaying: false
            }
        },
        created(){
            bus.$on('playAudio', ({src, uid}) => {
                if (this.isPlaying) {
                    this.pause();
                    this.onEnd();
                }

                this.uid = uid;
                if (/\.amr/.test(src)) {
                    src = `${config.apis.amr2mp3}?url=${src}`;
                }
                document.addEventListener("WeixinJSBridgeReady", function () {
                    var audio = new Audio();
                    audio.src = src;
                    audio.play();
                }, false);
                /*this.src = src;
                this.reload();
                this.play();*/
                console.log(this.src);
            });
            bus.$on('stopAudio', () => {
                if (this.isPlaying) {
                    this.pause();
                    this.onEnd();
                }
            });
        },
        mounted(){
            const el = this.$refs.audio;
            on(el, 'playing', u.bind(this.onPlaying, this));
            on(el, 'ended', u.bind(this.onEnd, this));
            on(el, 'error', u.bind(this.onError, this));
        },
        methods: {
            pause(){
                this.$refs.audio.pause();
            },
            play(){
                console.error('play');
                this.$refs.audio.play();
            },
            reload(){
                this.$refs.audio.load();
            },
            onPlaying(){
                console.error('playing');
                this.isPlaying = true;
                bus.$emit('audioPlayStart', {uid: this.uid});
            },
            onEnd(){
                console.error('end');
                this.isPlaying = false;
                bus.$emit('audioPlayEnd', {uid: this.uid});
            },
            onError(e){
                console.error(e);
                this.$toast({
                    message: '播放失败!',
                    duration: 2500
                });
                bus.$emit('audioPlayEnd', {uid: this.uid});
            }
        }
    }
</script>
