<template>
    <div>
        <div class="timestamp" v-if="showTimeString">{{ +msg.created | datetime}}</div>
        <div class="message" :class="type">
            <img :src="msg.portrait" v-if="type === 'receive'" class="avatar" @click="jumpToDoctorDetail(msg.fromUser)">
            <component :is="getTypeName(msg.type) + 'Msg'"
                       :type="type"
                       :content="msg.content || msg.attach || ''"
                       :length="msg.medialen"/>
            <transition>
                <i class="indicator fail" v-if="msg.fail" @click="resend">!</i>
                <mt-spinner class="indicator" type="snake" :size="20" v-else-if="!msg.created"></mt-spinner>
            </transition>
        </div>
    </div>
</template>

<style scoped lang="less" rel="stylesheet/less">
    @border-color: #EBEBF0;
    @primary-color: #BE3468;
    @text-color-black: #52525C;
    @text-color-white: #fff;
    .timestamp {
        text-align: center;
        font-size: 12px;
        margin-bottom: 10px;
    }

    .indicator {
        float: right;
        margin: 10px;
        &.fail {
            width: 20px;
            height: 20px;
            border-radius: 10px;
            background: @primary-color;
            color: @border-color;
            text-align: center;
            line-height: 20px;
            font-size: 16px;
            font-weight: bold;
        }
    }

    .message {
        width: 100%;
        overflow: hidden;
        position: relative;
        .avatar {
            position: absolute;
            bottom: 20px;
            left: 10px;
            width: 40px;
            height: 40px;
            border: 1px solid @border-color;
            border: thin solid @border-color;
            border-radius: 20px;
        }
        .content {
            max-width: 61.8%;
            min-width: 48px;
            line-height: 22px;
            font-size: 16px;
            border-radius: 18px;
            position: relative;
        }
        &.receive {
            padding: 0 10px 20px 56px;
            .content {
                float: left;
                background: #fff;
                border: thin solid @border-color;
                color: @text-color-black;
                border-bottom-left-radius: 4px;
            }
        }
        &.send {
            padding: 0 10px 20px 10px;
            .content {
                float: right;
                background: @primary-color;
                color: @text-color-white;
                border-bottom-right-radius: 4px;
            }
        }
    }

    .text-content {
        padding: 8px;
    }

    .image-content {
        padding: 5px;
        &.content-loading {
            padding: 8px;
        }
    }

    .voice-content {
        padding: 8px;
        color: #b3b3bd !important;
        &:after {
            content: '';
            position: absolute;
            width: 16px;
            height: 16px;
            top: 12px;
            right: 10px;
            background: url('../assets/img/icon_play.png') no-repeat;
            background-size: contain;
        }
        &.playing:after {
            animation: fadeInAndOut 1200ms infinite;
        }
        &.loading:after {
            display: none;
        }
    }

    @keyframes fadeInAndOut {
        0% {
            opacity: 1;
        }
        10% {
            opacity: 1;
        }
        40% {
            opacity: 0;
        }
        60% {
            opacity: 0;
        }
        90% {
            opacity: 1;
        }
        100% {
            opacity: 1;
        }
    }
</style>

<script type="text/javascript">
    import bus from 'src/event';
    import spinner from 'vue-spinner/src/BounceLoader';
    import {MessageBox} from 'mint-ui';
    import Enum from 'enum';
    import config from 'src/config';
    const MessageType = config.MessageType;
    const textMsg = {
        template: `<div class="content text-content">{{content}}</div>`,
        props: ['content']
    };
    const imageMsg = {
        template: `<div class="content image-content" :class="{'content-loading': isLoading}">
        <div class="image-preview" ref="image" @click="show"
        :style="'background: url('+content+'); width: '+width+'px; height: '+height+'px; border-radius: 13px;background-size:cover;'">
        <spinner v-if="isLoading" :color="type === 'send'? '#fff': '#BE3468'" size="24px"/>
        </div>`,
        props: ['content', 'type'],
        components: {spinner},
        data: () => ({
            width: 24,
            height: 24,
            realHeight: 0,
            realWidth: 0,
            isLoading: true
        }),
        created(){
            const image = new Image();
            image.src = this.content;
            const maxLength = window.innerWidth / 2;
            const maxRatio = 16 / 9;
            const minLength = maxLength / maxRatio;
            image.onerror = (e) => {
                this.isLoading = false;
            }
            image.onload = () => {
                this.isLoading = false;
                let w = image.width;
                let h = image.height;
                let r;
                if (w <= h) {
                    r = h / w;
                    if (h >= maxLength) {
                        this.height = maxLength;
                        this.width = maxLength / Math.min(maxRatio, r);
                    }
                    else {
                        this.height = h;
                        this.width = Math.max(minLength, w);
                    }
                }
                else {
                    r = w / h;
                    if (w >= maxLength) {
                        this.width = maxLength;
                        this.height = maxLength / Math.min(maxRatio, r);
                    }
                    else {
                        this.width = w;
                        this.height = Math.max(minLength, h);
                    }
                }
                this.realWidth = w;
                this.realHeight = h;
                bus.$emit('scrollDownMore', this.height - 24);
            };
        },
        methods: {
            show(){
                if (this.content) {
                    wx.previewImage({
                        current: this.content, // 当前显示图片的http链接
                        urls: [this.content] // 需要预览的图片http链接列表
                    });
                }
            }
        }
    };
    const voiceMsg = {
        template: `
        <div class="content voice-content" :class="{playing: isPlaying, loading: isLoading}"
            :style="'width:'+width+'px;'"
            @click="play">
            {{Math.floor(+length)}}″
            <mt-spinner style="position: absolute;top: 12px;right: 10px;"
                type="fading-circle" v-if="isLoading" :size="16">
            </mt-spinner>
        </div>`,
        props: ['content', 'length'],
        data: () => ({
            isPlaying: false,
            isLoading: false,
            audio: null
        }),
        computed: {
            width() {
                return 80 + 100 * (this.length / 60);
            },
            src(){
                let src = this.content;
                if (/\.amr/.test(src)) {
                    src = `${config.apis.amr2mp3}?url=${src}`;
                }
                return src;
            }
        },
        created(){
            bus.$on('stopVoice', () => {
                this.isPlaying = false;
                this.audio && this.audio.pause();
            })
        },
        methods: {
            play(){
                if (this.isPlaying) {
                    this.isPlaying = false;
                    this.audio && this.audio.pause();
                }
                else {
                    bus.$emit('stopVoice');
                    if (this.audio) {
                        this.audio.load();
                    }
                    else {
                        this.audio = new Audio();
                        this.audio.src = this.src;
                        this.isLoading = true;
                        this.audio.load();
                        this.audio.addEventListener('canplaythrough', () => {
                            this.audio.play();
                        });
                        this.audio.addEventListener('playing', () => {
                            this.isLoading = false;
                            this.isPlaying = true;
                        })
                        this.audio.addEventListener('ended', () => {
                            this.isPlaying = false;
                        });
                        this.audio.addEventListener('error', () => {
                            this.$toast({
                                message: '播放失败!',
                                duration: 2500
                            });
                            this.isLoading = false;
                            this.isPlaying = false;
                        })
                    }
                }
            }
        }
    }
    export default {
        name: 'message',
        props: ['msg', 'type', 'lastTimestamp'],
        components: {
            textMsg,
            imageMsg,
            voiceMsg
        },
        data: function () {
            return {}
        },
        computed: {
            showTimeString(){
                return +(this.msg.created || 0) - (+this.lastTimestamp) > 180000;
            }
        },
        methods: {
            jumpToDoctorDetail(doctorId){
                this.$router.push({
                    path: '/department',
                    query: {doctorId: doctorId.split('_').pop()}
                });
            },
            resend(){
                MessageBox.confirm('是否重新发送?')
                    .then(() => {
                        bus.$emit('resend', this.msg);
                    });
            },
            getTypeName(type){
                return MessageType.getNameByValue(type) || 'text';
            }
        }
    }
</script>
