/**
 * Created by zhouhua on 2016/12/20.
 */
import Vue from 'vue';
import VueRouter from 'vue-router';
import bus from 'src/event';
Vue.use(VueRouter);


import Chat from 'src/views/Chat';
import View from '../views/View';
import OrderDetail from '../views/OrderDetail/OrderDetail';
import CallUp from '../views/CallUp';
import bindPhoneNum from '../views/bindPhoneNum/bindPhoneNum';
import serviceOrder from '../views/serviceOrder/serviceOrder';

import ConfirmOrder from '../views/ConfirmOrder/ConfirmOrder';
import Coupon from '../views/Coupon/Coupon';

import Department from '../views/Department';
import Transaction from '../views/Transaction';
import Public from '../views/Public';
import SeePolicy from '../views/Insurance/SeePolicy';
import UserDissatisfied from '../views/Insurance/UserDissatisfied';
import CashCoupon from '../views/CashCoupon/CashCoupon';
import OrderState from '../views/Order/OrderState';

const routes = [{
        path: '/',
        redirect: '/chat'
    },
    {
        name: 'chat',
        path: '/chat',
        meta: {
            title: '图文咨询',
            keepAlive: false
        },
        component: Chat
    }, {
        name: 'confirmOrder',
        path: '/confirmOrder',
        meta: {
            title: '确认订单',
            keepAlive: true
        },
        component: ConfirmOrder
    }, {
        name: 'coupon',
        path: '/coupon',
        meta: {
            title: '优惠券',
            keepAlive: true
        },
        component: Coupon
    }, {
        name: 'department',
        path: '/department',
        meta: {
            title: '诊室',
            keepAlive: false
        },
        component: Department
    }, {
        name: 'bindphonenum',
        path: '/bindphonenum',
        meta: {
            title: '绑定手机号',
            keepAlive: false
        },
        component: bindPhoneNum
    }, {
        name: 'serviceorder',
        path: '/serviceorder',
        meta: {
            title: '订单',
            keepAlive: false
        },
        component: serviceOrder
    }, {
        name: 'view',
        meta: {
            title: '诊疗记录',
            keepAlive: false
        },
        path: '/view', //id
        component: View
    }, {
        name: 'orderdetail',
        meta: {
            title: '订单详情',
            keepAlive: false
        },
        path: '/order/detail', //abstractid
        component: OrderDetail
    }, {
        name: 'callup',
        path: '/callup',
        meta: {
            title: '免费电话',
            keepAlive: false
        },
        component: CallUp
    }, {
        name: 'transaction',
        path: '/transaction',
        meta: {
            title: '交易详情',
            keepAlive: false
        },
        component: Transaction
    }, {
        name: 'public',
        path: '/public',
        meta: {
            title: '关注公众号',
            keepAlive: false
        },
        component: Public
    }, {
        name: 'seePolicy',
        path: '/seePolicy',
        meta: {
            title: '查看保单-申请赔付',
            keepAlive: false
        },
        component: SeePolicy
    }, {
        name: 'userDissatisfied',
        path: '/userDissatisfied',
        meta: {
            title: '用户不满意险',
            keepAlive: false
        },
        component: UserDissatisfied
    }, {
        name: 'cashCoupon',
        path: '/cashCoupon',
        meta: {
            title: '代金券说明',
            keepAlive: false
        },
        component: CashCoupon
    }, {
        path: '/order/cancel',
        meta: {
            title: '',
            keepAlive: false
        },
        component: OrderState
    }, {
        path: '/order/notexist',
        meta: {
            title: '',
            keepAlive: false
        },
        component: OrderState
    }, {
        path: '/order/alreadypaid',
        meta: {
            title: '',
            keepAlive: false
        },
        component: OrderState
    }
];

const router = new VueRouter({
    // mode: 'history',
    routes
});

// 路由导航钩子，beforeEach，在路由进入前调用
router.beforeEach((to, from, next) => {
    bus.$emit('changeTitle', to.meta.title);
    // 继续路由导航
    next();
});



export default router;