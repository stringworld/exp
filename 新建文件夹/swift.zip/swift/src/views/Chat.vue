<template>
    <div class="chat-room" :class="{'no-footer': readOnly}">
        <div class="wrap" ref="wrap" @scroll="loadMore">
            <div class="chat-loading">
                <div class="loading-content" v-show="fetching">
                    <spin class="spin" color="#888" size="8px"/>
                    加载中
                </div>
            </div>
            <message v-for="(message, index) in messages"
                     :key="message.id"
                     :msg="message"
                     :type="message.fromUser === memberId? 'receive': 'send'"
                     :lastTimestamp="index > 0? messages[index-1].created: 0"
            />
        </div>
        <footer-input v-if="!readOnly" @send='send'/>
    </div>
</template>

<script type="text/javascript">
    import Message from 'src/components/Message';
    import FooterInput from 'src/components/FooterInput';
    import Spin from 'vue-spinner/src/BeatLoader';
    import wxinit from 'src/wxinit';
    import config from 'src/config';
    import Enum from 'enum';
    import u from 'underscore';
    import {MessageBox} from 'mint-ui';
    import bus from 'src/event';

    const CommandType = new Enum([
        {name: 'CHAT', value: 'c'},
        {name: 'ACK', value: 'a'},
        {name: 'SYN', value: 's'},
        {name: 'SYN_REPLY', value: 'r'},
        {name: 'PING', value: 'p'},
        {name: 'PONG', value: 'q'},
        {name: 'SYS_MSG', value: 'm'}
    ]);

    const WebsocketStatus = new Enum([
        {name: 'CONNECTING', value: 0},
        {name: 'OPEN', value: 1},
        {name: 'CLOSING', value: 2},
        {name: 'CLOSED', value: 3}
    ]);
    const QueryDirection = new Enum([
        {name: 'backwards', value: '1'},
        {name: 'forwards', value: '0'}
    ]);

    const OrderStatus = new Enum([
        {name: 'FINISHED', value: 'finish'}
    ]);

    export default {
        name: 'chat',
        components: {
            Message,
            FooterInput,
            Spin
        },
        created(){
            wxinit(['startRecord', 'stopRecord', 'chooseImage', 'uploadImage', 'translateVoice']);
            setTimeout(() => this.checkOrderId(), 100);
            if (config.wss) {
                this.$nextTick(() => {
                    this.ws = new WebSocket(config.wss);
                    this.ws.onerror = (e) => {
                        console.error(e);
                    }
                    this.ws.onopen = () => {
                        console.log('ws opened');
                        this.checkReady();
                        // keep webSocket alive
                        this.pingClock = setInterval(() => {
                            this.ws.send(`${CommandType.PING}{}`);
                        }, 45000);
                    }
                    this.ws.onmessage = msg => {
                        this.$nextTick(() => this.receive(msg));
                    }
                });
                this.$on('ready', () => {
                    this.loadData();
                    while (this.queue.length) {
                        let msg = this.queue.shift();
                        msg.serveId = this.orderId;
                        this.ws.send(`${CommandType.CHAT}${JSON.stringify(msg)}`);
                    }
                });
            }
            let lastBottom = 48;
            bus.$on('changePaddingBottom', bottom => {
                this.$refs.wrap.style.paddingBottom = `${bottom}px`;
                if (bottom > lastBottom) {
                    window.aaa = this.$refs.wrap;
                    this.$refs.wrap.scrollTop += (bottom - lastBottom);
                }
                lastBottom = bottom;
            });
            bus.$on('resend', this.send);
            this.$on('scrollDown', () => {
                this.$nextTick(() => {
                    this.$refs.wrap.scrollTop = this.$refs.wrap.scrollHeight;
                });
            });
            bus.$on('scrollDownMore', more => {
                this.$nextTick(() => {
                    this.$refs.wrap.scrollTop += more;
                });
            });
        },
        beforeDestroy(){
            if (this.ws && u.include([WebsocketStatus.CONNECTING, WebsocketStatus.OPEN], this.ws.readyState)) {
                this.ws.close();
            }
            if (this.pingClock) {
                clearInterval(this.pingClock);
            }
            bus.$emit('stopVoice');
        },
        methods: {
            checkOrderId(){
                if (!this.orderId) {
                    this.$http.get(config.apis.createChatOrder, {
                        params: {
                            accepter: this.memberId
                        }
                    }).then(({data}) => {
                        console.log(data);
                        if (!data.code) {
                            this.orderId = data.data.abstractId;
                            this.checkReady();
                        }
                    }).catch(e => console.error(e));
                }
            },
            loadData(){
                this.fetching = true;
                const params = {
                    limit: '10',
                    serveId: this.orderId,
                    toUser: this.memberId,
                    back: QueryDirection.backwards,
                    startId: this.lastId || ''
                }
                this.$nextTick(() => this.ws.send(`${CommandType.SYN}${JSON.stringify(params)}`));
            },
            loadMore(){
                if (this.$refs.wrap.scrollTop > 0 || this.fetching & !this.isReady || this.noMore) {
                    return;
                }
                this.loadData();
            },
            sendFail(msg){
                msg.fail = true;
                if (this.showingErrorModal) {
                    return;
                }
                this.showingErrorModal = true;
                MessageBox.alert('消息发送失败!').then(() => {
                    this.showingErrorModal = false;
                });
                const i = u.lastIndexOf(this.messages, msg);
                this.messages.splice(i, 1, {...msg});
            },
            sendMessage(msg){
                if (this.isReady) {
                    msg.serveId = this.orderId;
                    this.ws.send(`${CommandType.CHAT}${JSON.stringify(msg)}`);
                }
                else {
                    this.queue.push(msg);
                }
            },
            send(msg){
                msg = {...msg};
                msg.fail = false;
                msg.toUser = this.memberId;
                if (!msg.id) {
                    this.$http.get(config.apis.getUid).then(({data}) => {
                        if (data.code) {
                            throw new Error('bad request');
                        }
                        msg.id = data.data.id;
                        this.sendMessage(msg);
                        this.messages.push(msg);
                        this.$emit('scrollDown');
                    }).catch(() => {
                        if (msg.clock) {
                            clearTimeout(msg.clock);
                        }
                        this.sendFail(msg);
                    });
                }
                else {
                    this.sendMessage(msg);
                    const index = u.findLastIndex(this.messages, {id: msg.id});
                    if (index >= 0) {
                        this.messages.splice(index, 1, msg);
                    }
                    else {
                        this.messages.push(msg);
                    }
                }
                msg.clock = setTimeout(() => {
                    this.sendFail(msg);
                }, 60000);
            },
            finishLoad(){
                this.fetching = false;
            },
            checkReady(){
                if (this.orderId && this.ws && this.ws.readyState === WebsocketStatus.OPEN) {
                    this.$emit('ready');
                    this.isReady = true;
                }
            },
            receive(msg){
                if (!msg.data) {
                    return;
                }
                const matches = msg.data.match(/^([a-z])(.*)$/);
                if (matches && matches.length === 3) {
                    const command = matches[1];
                    const info = JSON.parse(matches[2] || '{}');
                    switch (command) {
                        case CommandType.SYN_REPLY: {
                            if (info.msgs.length < 10) {
                                this.noMore = true;
                            }
                            this.messages.splice(0, 0, ...info.msgs.reverse());
                            this.finishLoad();
                            if (!this.inited) {
                                this.$emit('scrollDown');
                                this.inited = true;
                            }
                            break;
                        }
                        case CommandType.CHAT: {
                            if (info) {
                                this.messages.push(info);
                            }
                            this.$emit('scrollDown');
                            break;
                        }
                        case CommandType.ACK: {
                            if (info) {
                                let index = u.findLastIndex(this.messages, {id: info.id});
                                if (index >= 0) {
                                    let message = {...this.messages[index], ...info};
                                    if (message.clock) {
                                        clearTimeout(message.clock);
                                    }
                                    this.messages.splice(index, 1, message);
                                }
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
            }
        },
        data: function () {
            return {
                messages: [],
                queue: [],
                orderId: this.$route.query.order,
                memberId: this.$route.query.member,
                doctorId: (this.$route.query.member || '').split('_')[1],
                orderStatus: this.$route.query.status,
                noMore: false,
                fetching: true,
                isReady: false,
                showingErrorModal: false,
                pingClock: null,
                inited: false
            };
        },
        computed: {
            lastId(){
                const index = u.findIndex(this.messages, message => !!message.created);
                return index >= 0 ? this.messages[index].id : null;
            },
            readOnly(){
                return this.orderStatus === OrderStatus.FINISHED;
            }
        }
    }
</script>

<style lang="less" rel="stylesheet/less">
    .chat-room {
        height: 100%;
        width: 100%;
        position: absolute;
        padding: 0 0 50px 0;
        background: #F7F6F9;
        transition: all .2s;
        &.no-footer {
            padding-bottom: 20px;
        }
    }

    .wrap {
        overflow: auto;
        width: 100%;
        height: 100%;
        -webkit-overflow-scrolling: touch;
    }

    .chat-loading {
        width: 100%;
        height: 20px;
        text-align: center;
        line-height: 20px;
        .loading-content {
            display: inline-block;
            font-size: 12px;
            line-height: 12px;
            .spin {
                float: left;
                margin-right: 5px;
                height: 12px;
                overflow: hidden;
            }
        }
    }
</style>
