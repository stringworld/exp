<template>
    <section class="swift-detail">
        <section class="swif-bgcolor">
            <dl class="swift-introduce">
                <dt :style="{'background':'url('+doctor.portrait+') no-repeat center'}">

            </dt>
                <dd>
                    <h3><strong>{{doctor.name}}</strong><span>{{doctor.doctorType}}</span></h3>
                    <p class="swift-introduce-title"><span>{{doctor.title}}</span><span>{{doctor.address}}</span></p>
                    <p class="swift-introduce-label"><span v-for="i in doctor.specialtyList">{{i}}</span></p>
                </dd>
            </dl>

            <ul class="swift-list">
                <li class="swift-list-consult" @click="chat">
                    <i><img src="../assets/img/icon_chat@2x.png"/></i> 图文咨询
                    <span><img src="../assets/img/arrow@2x.png"/></span>
                </li>
            </ul>
        </section>
        <section class="swif-bgcolor">

            <div class="swif-detail">
                <template v-for="item in contentList">
                    <h3 class="swift-detail-title">{{item.title}}</h3>
                    <p class="swift-detail-content">{{item.content}}</p>
                </template>
            </div>
        </section>
    </section>
</template>
<script type="text/javascript">
    import bus from 'src/event';
    export default {
        data() {
                return {
                    id: this.$route.query.doctorId,
                    doctor: {
                        specialtyList: []
                    },
                    orderId: null,
                    isQueryQrderId: true,
                    queryOrderId: null,
                    contentList: []
                }
            },
            computed: {
                ContentTypeList() {
                    if (this.ContentType) {
                        return this.ContentType.toArray();
                    }
                }
            },
            created() {
                this.$http.get('/doctor/clinic/', {
                        params: {
                            doctorId: this.id
                        }
                    })
                    .then(({
                        data
                    }) => {
                    	const contentList = [];
                    	const string = data.data.description || '';
                    	var matches = string.match(/(【[^】]+】[^【]+)/g);
                    	if(matches && matches.length){
                    		for(var i = 0; i< matches.length; i++){
                    			var subString = matches[i];
                    			var subMatches = subString.match(/【([^】]+)】([^【]+)/);
                    			if(subMatches && subMatches.length >1){
                    				contentList.push({
                    					title: subMatches[1],
                    					content: subMatches[2]
                    				})
                    			}
                    		}
                    	}
                    	this.contentList = contentList;
                        this.doctor = data.data;
                        bus.$emit('changeTitle', this.doctor.name + '的诊室');

                        this.queryOrderId = this.$http.get('/get/chat/order/', {
                            params: {
                                employedId: this.id
                            }
                        }).then(({
                            data
                        }) => {
                            this.isQueryOrderId = false;
                            if (!data.code) {
                                this.orderId = data.data.orderId;
                            }
                        })
                    });
            },
            methods: {
                chat() {
                    if (!this.doctor.memberId) {
                        return;
                    }
                    const self = this;

                    function redirect() {
                        self.$router.push({
                            path: '/chat',
                            query: {
                                member: self.doctor.memberId,
                                order: self.orderId || ''
                            }
                        });
                    };
                    if (this.isQueryOrderId) {
                        this.queryOrderId.then(redirect);
                    }
                    else {
                        redirect();
                    }
                }
            }
    }
</script>
<style lang="less" scoped rel="stylesheet/less">
    .swift-detail {
        background-color: #f8f7fa;
        .swif-bgcolor {
            background-color: #fff;
            .swift-introduce {
                position: relative;
                margin-left: 4%;
                padding: 10px 4% 5px 0;
                overflow: hidden;
                border-bottom: 1px solid #EBEBF0;
                dt {
                    position: absolute;
                    left: 0;
                    top: 10px;
                    width: 65px;
                    padding-bottom: 65px;
                    border-radius: 50%;
                    background-size: cover !important;
                }
                dd {
                    padding-left: 75px;
                    padding-top: 9px;
                    font-size: 16px;
                    h3 {
                        line-height: 26px;
                        font-weight: normal;
                        strong {
                            margin-right: 10px;
                            font-size: 20px;
                        }
                        span {
                            font-size: 16px;
                            color: #B3B3BD;
                        }
                    }
                    .swift-introduce-title {
                        padding-bottom: 5px;
                        line-height: 20px;
                        span {
                            font-size: 16px;
                            color: #83838F;
                            padding-right: 10px;
                        }
                    }
                    .swift-introduce-label {
                        overflow: hidden;
                        span {
                            float: left;
                            margin-right: 5px;
                            margin-bottom: 5px;
                            padding: 0 7px;
                            line-height: 23px;
                            font-size: 14px;
                            color: #BE3468;
                            border: 1px solid #BE3468;
                            border-radius: 5px;
                        }
                    }
                }
            }
            .swift-list {
                padding: 20px 4%;
                .swift-list-consult {
                    height: 45px;
                    line-height: 45px;
                    overflow: hidden;
                    list-style: none;
                    font-size: 18px;
                    font-weight: 500;
                    color: #52525C;
                    i {
                        float: left;
                        margin-right: 10px;
                        img {
                            width: 45px;
                            height: 45px;
                        }
                    }
                    span {
                        float: right;
                        img {
                        	width: 11px;
                            vertical-align: middle;
                        }
                    }
                }
            }
            .swif-detail {
            	margin-top: 15px;
                padding: 10px 4% 15px;
                line-height: 26px;
                .swift-detail-title {
                    padding-top: 10px;
                    font-size: 16px;
                    color: #52525C;
                    font-weight: bold;
                    &:before {
                        padding-left: 10px;
                        content: '';
                        border-left: 3px solid #BE3468;
                    }
                }
                .swift-detail-content {
                	line-height: 24px;
                    white-space: pre-wrap;
                    word-break: break-all;
                    font-size: 16px;
                    color: #353500;
                }
            }
        }
    }
</style>
