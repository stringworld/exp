<template>
    <section class="swift-transaction">
        <dl class="swift-transaction-success">
            <dt><img src="../assets/img/img_done@2x.png" /></dt>
            <dd>支付成功</dd>
        </dl>
        <ul class="swift-transaction-list">
            <li>
                <strong>服务名称：</strong>
                <span>{{patient.serviceInfo.name}}</span>
            </li>
            <li>
                <strong>交易时间：</strong>
                <span>{{patient.payInfo.tradingTime}}</span>
            </li>
            <li>
                <strong>订单总额：</strong>
                <span>{{patient.payInfo.orderPrice}}</span>
            </li>
            <li>
                <strong>实付金额：</strong>
                <span>{{patient.payInfo.actualPayAmount}}</span>
            </li>
            <li>
                <strong>订单编号：</strong>
                <span>{{patient.abstractId}}</span>
            </li>
        </ul>
        <router-link to="/public" v-if="patient.serviceInfo.type=='DOOR_SERVICE'">
            <dl class="swift-transaction-public">
                <dt><img src="../assets/img/arrow@2x.png" /></dt>
                <dd>
                    <h3>关注米喜医家公众号</h3>
                    <p>助于及时同步订单最新进度</p>
                </dd>
            </dl>
        </router-link>
        <dl class="swift-transaction-public" @click='down' v-else>
            <dt><img src="../assets/img/arrow@2x.png" /></dt>
            <dd>
                <h3>下载米喜医家APP</h3>
                <p>使用米喜医家APP查看订单最新进度</p>
            </dd>
        </dl>
    </section>
</template>
<script type="text/javascript">
    import wxinit from 'src/wxinit';
    export default {
        data() {
            return {
                id: this.$route.query.id,
                patient: {
                    payInfo: {},
                    serviceInfo: {}
                }
            }
        },
        created() {
            this.$http.get('/patient/order/detail/', {
                params: {
                    abstractId: this.id
                }
            })
                .then(({
                    data
                }) => {
                    this.patient = data.data;
                });
            wxinit(['showOptionMenu']);
        },
        methods: {
            down() {
                wx.showOptionMenu();
                setTimeout(() => window.location.href = 'http://www.medishare.cn/m/d2.html', 100);
            }
        }
    }
</script>
<style lang="less" scoped rel="stylesheet/less">
    .swift-transaction {
        background-color: #f8f7fa;
        .swift-transaction-success {
            height: 110px;
            line-height: 70px;
            padding: 20px 4%;
            overflow: hidden;
            background-color: #fff;
            dt {
                float: left;
                margin-right: 20px;
                img {
                    width: 70px;
                }
            }
            dd {
                float: left;
                font-size: 24px;
                color: #52525C;
                font-weight: bold;
            }
        }
        .swift-transaction-list {
            padding: 20px 4%;
            margin: 15px 0;
            background-color: #fff;
            li {
                line-height: 30px;
                overflow: hidden;
                list-style: none;
                font-size: 16px;
                strong {
                    float: left;
                    color: #52525C;
                    font-weight: normal;
                }
                span {
                    float: right;
                    color: #B3B3BD;
                }
            }
        }
        .swift-transaction-public {
            padding: 20px 4%;
            line-height: 50px;
            overflow: hidden;
            background-color: #fff;
            dt {
                float: right;
                img {
                    width: 12px;
                    vertical-align: middle;
                }
            }
            dd {
                float: left;
                line-height: 26px;
                h3 {
                    font-size: 20px;
                    color: #52525C;
                }
                p {
                    font-size: 14px;
                    color: #B3B3BD;
                }
            }
        }
    }
</style>
