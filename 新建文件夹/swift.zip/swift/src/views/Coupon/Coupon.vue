<template>
    <section class="page-coupon">
        <p class="remind">只显示有效期内的代金券<span>
            代金券说明
             <router-link to="cashCoupon" tag="a" class="help">
                ?
            </router-link>
            </span>
        </p>
        <div class="coupon-list">
            <a v-on:click="select('')" class="no-coupon" v-bind:class="{active:selectedCouponId===''}">不使用代金券</a>
            <dl v-for="coupon in couponList" v-bind:class="{active:coupon.id==selectedCouponId}" v-on:click="select(coupon.id)">
                <dt>{{coupon.amtDesc}}</dt>
                <dd>
                    <h3>{{coupon.title}}</h3>
                    <h4>使用期限</h4>
                    <em>{{coupon.expiration}}</em>
                </dd>
            </dl>

        </div>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">
   @import './Coupon.less';
</style>
<script type="text/javascript">
    import bus from 'src/event.js';
    export default {
        data() {
            return {
                couponList: null,
                selectedCouponId: '',
                abstractId: this.$route.query.abstractid
            }
        },
        created() {
            this.$http.get('/coupon/list/').then(({data}) => {
                this.couponList = Object.assign({}, this.couponList, data.data.couponList)
            });
        },
        methods: {
            select(couponId) {
                this.selectedCouponId = couponId;
                this.$router.push({ path: 'ConfirmOrder', query: { couponId: couponId, abstractid: this.abstractId } });
                //this.$router.go(-1);
                // bus.$emit('indicatorShow');
                // var self = this;
                // this.$http.get('/coupon/locking/', {
                //     params: {
                //         abstractId: this.abstractId,
                //         couponId: this.selectedCouponId
                //     }
                // })
                //     .then(function () {
                //         bus.$emit('indicatorHide');
                //         self.$router.go(-1);
                //     })
                //     .catch((error) => {
                //         bus.$emit('indicatorHide');
                //         this.$toast(error);
                //     })

            }
        }
    }

</script>