<template>
    <section class="page-ConfirmOrder">
        <order-steps step="step-pay" />
        <div class="service-info-box">
            <ul class="service-info">
                <li>
                    <i class="font-dark">服务名称</i>
                    <em class="font-subdark">{{orderInfo.serviceName}}</em>
                </li>
                <li>
                    <i class="font-dark">服务医生</i>
                    <em class="font-subdark">{{orderInfo.serviceDoctor}}</em>
                </li>
                <li>
                    <i class="font-dark">服务时间</i>
                    <em class="font-subdark">{{orderInfo.serviceTime}}</em>
                </li>
                <li>
                    <i class="font-dark">服务总额</i>
                    <em class="font-winered">{{orderInfo.serviceAmount}}</em>
                </li>

            </ul>
        </div>

        <div class="service-item-box mb10">
            <h3>服务项</h3>
            <ul class="service-item">
                <li v-for="item in orderInfo.serviceDetail" class="font-subdark">{{item}}</li>
            </ul>
        </div>
        <div class="service-basic-box item-box-bottom">
            <ul class="service-basic">
                <li>
                    <i class="font-dark">联系人名称</i>
                    <input class="font-subdark" v-model.trim="orderInfo.contactName" type="text" placeholder="请输入姓名" />
                </li>
                <li v-if="!(orderInfo.serviceType=='PRIVATE_DOCTOR')">
                    <i class="font-dark">上门地址</i>
                    <input class="font-subdark" v-model.trim="orderInfo.homeAddress" type="text" placeholder="请输入地址" />
                </li>
                <li>
                    <router-link to="UserDissatisfied" tag="i" class="font-dark">
                        用户不满意险
                        <a class="help font-winered">?</a>
                    </router-link>

                    <em class="font-winered present" v-bind:class="{on:isPresent}" v-on:click="changePresent ">赠送</em>

                </li>
                <router-link :to="{path:'coupon',query:{abstractid:abstractId}}" tag="li">
                    <i class="font-dark">代金券</i>
                    <em class="font-winered discount" v-bind:class="{disable:!orderInfo.hasCoupon}">{{discountText}}<span></span></em>
                </router-link>
            </ul>

        </div>
        </ul>
        <dl class="orderPay">
            <dt>
                合计：<em class="font-winered">{{orderInfo.price}}</em>
            </dt>
            <dd v-on:click="pay">
                微信支付
            </dd>
        </dl>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">
   @import './ConfirmOrder.less';
</style>
<script type="text/javascript">
    import OrderSteps from '../../components/OrderSteps';
    import debounce from 'debounce'
    import wxinit from 'src/wxinit';
    import bus from 'src/event.js';
    import { MessageBox } from 'mint-ui';
    export default {
        data() {
            return {
                orderInfo: {},
                isPayAvailable: true,
                abstractId: '',
                activedTimes: 0
            }
        },
        components: {
            OrderSteps
        },
        created() {
            this.abstractId = '';
            this.fetchOrder()
                .then((isRedirect) => {
                    if (!isRedirect) { this.fetchPrice(); }
                })
            // this.fetchOrder()
            //     .then(({data}) => {
            //         if (!data.code) {
            //             // ...
            //         }
            //         return data.data.id;
            //     })
            //     .then((id) => {
            //         this.fetchPrice(id)
            //     })


            // async function fetchAll() {
            //     var {data} = await this.fetchOrder();
            //     var id = data.data.id;
            //     var xxx = await this.fetchPrice(id);
            // }

            // fetchAll.call(this);

        },
        activated() {
            this.activedTimes += 1;
            if (this.activedTimes !== 0 && this.orderInfo.serviceName) {//第二次进入到当前页
                this.fetchPrice()
            }

            wxinit(['chooseWXPay', 'closeWindow']);
        },
        computed: {
            discountText() {
                if (this.orderInfo.couponText) return this.orderInfo.couponText;
                return this.orderInfo.hasCoupon ? "有代金券可用" : "无代金券可用"
            },
            isPresent() {
                if (this.orderInfo.insuranceList) {
                    if (this.orderInfo.insuranceList[0].hasFree == true) return true
                }
            }
        },
        methods: {
            changePresent() {
                this.orderInfo.insuranceList[0].hasFree = !this.orderInfo.insuranceList[0].hasFree;
                this.debounceFetchPrice()
            },
            debounceFetchPrice: debounce(function () {
                this.fetchPrice();
            }, 400),
            fetchOrder() {
                return this.$http.get('/load/confirm/order/', {
                    params: {
                        abstractId: this.$route.query.abstractid
                    }
                })
                    .then(({data}) => {
                        if (!data.code) {
                            this.abstractId = data.data.abstractId;
                            if (data.data.orderStatus == 'notExist') {
                                this.$router.replace({ path: 'order/notexist' });
                                return true;
                            }
                            if (data.data.orderStatus == 'cancel') {
                                this.$router.replace({ path: 'order/cancel' });
                                return true;
                            }
                            if (data.data.orderStatus == 'alreadyPaid') {
                                this.$router.replace({ path: 'order/alreadypaid' });
                                return true;
                            }
                            this.orderInfo = Object.assign({}, this.orderInfo, data.data);
                        } else {
                            this.$toast(data.errorMsg);
                        }
                        return false
                    });

            },
            fetchPrice() {
                bus.$emit('indicatorShow');
                return this.$http.get('/calculated/price/', {
                    params: {
                        couponId: this.$route.query.couponId || '',
                        insurances: this.orderInfo.insuranceList[0].id || '',
                        abstractId: this.orderInfo.abstractId || this.$route.query.abstractid
                    }
                })
                    .then(({data}) => {
                        //console.log(data);
                        this.orderInfo = Object.assign({}, this.orderInfo, data.data)
                        bus.$emit('indicatorHide');
                        return data;
                    }, (error) => {
                        bus.$emit('indicatorHide');
                        this.$toast(error);
                    });
            },
            pay() {
                if (!this.isPayAvailable) return;
                if (!this.orderInfo.contactName) { MessageBox("请填写您的姓名"); return; }
                if (!this.orderInfo.homeAddress && !(this.orderInfo.serviceType == 'PRIVATE_DOCTOR')) { MessageBox("请填写您的服务地址！"); return; }
                // this.isPayAvailable = false;
                var self = this;
                this.$http.post('/pay/prepay/wechat/', {
                    couponId: this.$route.query.couponId || '',
                    abstractId: this.orderInfo.abstractId || this.$route.query.abstractid,
                    contactName: this.orderInfo.contactName || '',
                    // couponIds: this.orderInfo.couponIds,
                    homeAddress: this.orderInfo.homeAddress || '',
                    insurances: this.orderInfo.insuranceList[0].hasFree ? this.orderInfo.insuranceList[0].id : ''
                })
                    .then(({data}) => {
                        if (!data.code) {
                            if (data.data.hasPay) {
                                this.$router.replace({ path: 'transaction', query: { id: this.orderInfo.abstractId || this.$route.query.abstractid } }) //支付成功页面
                                return;
                            }
                            wx.checkJsApi({
                                jsApiList: ['chooseWXPay'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
                                success: function (res) {
                                    if (res.checkResult.chooseWXPay === "no") {
                                        MessageBox("请使用手机端微信支付");
                                        return;
                                    }

                                    // 以键值对的形式返回，可用的api值true，不可用为false
                                    // 如：{"checkResult":{"chooseWXPay":"no"},"errMsg":"checkJsApi:ok"}
                                }
                            });
                            wx.chooseWXPay({
                                timestamp: data.data.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
                                nonceStr: data.data.nonceStr, // 支付签名随机串，不长于 32 位
                                package: data.data.extendPackage, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=***）
                                signType: "MD5", // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
                                paySign: data.data.paySign, // 支付签名.
                                success: function (res) {
                                    this.isPayAvailable = true;
                                    wx.closeWindow();
                                    //self.$router.replace({ path: 'transaction', query: { id: self.$route.query.abstractid } });
                                },
                                error: function (res) {
                                    bus.$emit('indicatorHide');
                                    WeixinJSBridge.log(res.err_msg);
                                    this.isPayAvailable = true;
                                    this.$toast(res);
                                }
                            });
                        } else {
                            bus.$emit('indicatorHide');
                            this.$toast(data.errorMsg);
                        }
                    })
                    .catch((error) => {
                        this.isPayAvailable = true;
                        bus.$emit('indicatorHide');
                        this.$toast(error);
                    });
            }
        }
    }

</script>