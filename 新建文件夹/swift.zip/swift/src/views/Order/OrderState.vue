<template>
    <div class="swift-order">
        <div class="swift-order-content">
            <img src="../../assets/img/img_order@2x.png" />
            <p>{{orderText}}</p>
        </div>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    .swift-order {
    	width: 100%;
        line-height: 20px;
        display: table;
        height: 100%;
        background-color: #f8f7fa;
        .swift-order-content {
            display: table-cell;
            vertical-align: middle;
            p {
                padding-top: 10px;
                font-size: 18px;
                color: #B3B3BD;
                text-align: center;
                letter-spacing: 2px;
            }
            img {
                display: block;
                width: 90px;
                margin: 0 auto;
            }
        }
    }
</style>
<script type="text/javascript">
    import bus from 'src/event';
    export default {
        data() {
                return {
                    isCancel: /cancel/.test(this.$route.path),
                    isAlreadypaid: /alreadypaid/.test(this.$route.path),
                    orderText: ''
                }
            },
            created() {
                if ( this.isCancel ) {
                    this.orderText = '该订单已取消';
                    bus.$emit('changeTitle', '订单');
                }
                else if ( this.isAlreadypaid ) {
                    this.orderText = '该订单已支付';
                    bus.$emit('changeTitle', '订单');
                }
                else {
                    this.orderText = '暂无订单'
                    bus.$emit('changeTitle', '暂无订单');
                }
                //this.orderText = this.isCancel ? '该订单已取消' : '暂无订单';
                //bus.$emit('changeTitle', this.isCancel ? '订单' : '暂无订单');
                bus.$emit('indicatorHide');
            }
    }
</script>