<template>
    <form class="bind-phone">
        <div class="form-row">
            <input type="number" class="block-input" placeholder="请输入手机号码" v-model="phone" />
        </div>
        <div class="form-row">
            <input type="number" class="code-input" placeholder="请输入验证码" v-model="code" />
            <button type="button" class="verify-btn" :disabled="!phoneValid || counting" @click="sendVerifyCode">{{verify.text}}
            </button>
        </div>
        <p class="text-error">
            {{errorText}}
        </p>
        <button type="button" class="form-row bind-btn" :disabled="!phoneValid || !codeValid || waiting" @click="bindPhoneNum">绑定
        </button>
        <p class="text-muted text-center">
            绑定手机号有助于向您及时同步订单最新进度
        </p>
    </form>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import './bindPhoneNum.less';
</style>

<script type="text/javascript">
    import router from 'src/routes';
    import bus from 'src/event';
    import { MessageBox } from 'mint-ui';

    export default {
        data() {
            return {
                changeTitle: '绑定手机号',
                phone: '',
                code: '',
                // phoneValid: false,
                // codeValid: false,
                showCodeMes: false,
                verify: {
                    text: '获取验证码'
                },
                counting: false,
                waiting: false
            }
        },
        created() {
            // bus.$emit('changeTitle',this.changeTitle);
        },
        computed: {
            phoneValid() {
                return this.validateMobile(this.phone);
            },
            codeValid() {
                return this.validateCode(this.code);
            },
            errorText() {
                if (this.phone || this.code) {
                    if (!this.phoneValid) {
                        return '请输入正确的手机号码';
                    }
                    if (!this.phone) {
                        return '请输入手机号码';
                    }
                    if (!this.showCodeMes) {
                        return;
                    }
                    if (!this.code) {
                        return '请输入验证码';
                    }
                    if (!this.codeValid) {
                        return '请输入正确的验证码';
                    }
                    return '';
                }
            }
        },
        methods: {
            countingDown(time = 60) {
                if (time > 0) {
                    this.counting = true;
                    const self = this;
                    this.verify.text = `${time}秒`;
                    setTimeout(function () {
                        self.countingDown(time - 1);
                    }, 1000);
                } else {
                    this.counting = false;
                    this.verify.text = '获取验证码';
                }
            },
            validateMobile(mobile = '') {
                return /^1[345789]\d{9}$/.test(mobile);
            },
            validateCode(code = '') {
                return /^\d{4}$/.test(code);
            },
            sendVerifyCode() {
                //如果是false就开始倒计时，如果是true就停止倒计时
                if (this.phoneValid) {
                    this.$http.get('/member/bindCode/', { params: { mobile: this.phone } }).then(({data}) => {
                        if (!data.code) {
                            this.showCodeMes = true;
                            this.countingDown();
                        } else {
                            this.showCodeMes = false;
                            MessageBox('提示', data.errorMsg);
                        }
                    });
                }
            },
            bindPhoneNum() {
                if (this.phoneValid && this.codeValid && !this.waiting) {
                    this.waiting = true;
                    this.$http.get('/member/binding/', {
                        params: {
                            mobile: this.phone,
                            code: this.code
                        }
                    }).then(({data}) => {
                        this.waiting = false;
                        if (!data.code) {
                            this.code = '';
                            this.$router.replace({ path: decodeURIComponent(this.$route.query.redirect_uri || '#').split('#')[1] });
                        } else {
                            MessageBox('提示', data.errorMsg);
                        }
                    }, () => {
                        this.waiting = false;
                    });
                }
            }
        }
    }
</script>