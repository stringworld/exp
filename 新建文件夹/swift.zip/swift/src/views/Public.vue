<template>
    <section class="swift-center">
        <section class="swift-public">
            <h3>关注米喜医家</h3>
            <p>医+,您的家庭医生</p>
            <img src="../assets/img/medishare-code.jpg" />
            <section class="swift-public-introduce">
                <span>长按二维码 </span>
                <span>关注公众号</span>
            </section>
        </section>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">
    .swift-center {
            background-color: #f8f7fa;
        .swift-public {
            padding: 40px 18%;
            line-height: 20px;
            background-color: #fff;
            h3 {
                font-size: 24px;
                color: #52525C;
                font-weight: bold;
                text-align: center;
            }
            p {
                padding: 10px 0;
                font-size: 18px;
                color: #B3B3BD;
                text-align: center;
            }
            img {
                width: 100%;
            }
            .swift-public-introduce {
                overflow: hidden;
                span {
                    float: left;
                    width: 50%;
                    font-size: 20px;
                    color: #83838F;
                    text-align: center;
                }
            }
        }
    }
</style>