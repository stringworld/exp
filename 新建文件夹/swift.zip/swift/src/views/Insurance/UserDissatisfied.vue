<template>
    <section class="swift-user">
        <section class="swift-user-content">
            <h3 class="insurance_h3">保险特色</h3>
            <ul class="hurtDanger_list">
                <li>行医资质保障</li>
                <li>服务质量保障</li>
                <li>隐私安全</li>
                <li>原款返还</li>
            </ul>
        </section>
        <hr class="division-border" />
        <section class="swift-user-content">
            <h3 class="insurance_h3">保险详情</h3>
            <section class="insurance_details">
                <p class="textIndext">由于因下列原因取消订单或未按照约定使用预定项目的，导致用户已经支付的预定费用无法返还。而实际产生的经济损失，按合同约定负责赔偿，赔偿上限为订单的服务费金额。原因主要为：</p>
                <p>1、医生在服务过程中谩骂、诋毁、侮辱、恶意中伤用户等行为；</p>
                <p>2、医生私自将用户相关信息直接或间接用于其他商业用途；</p>
                <p>3、医生以获利为目的，以欺骗的手段让用户进行明显不当消费行为；</p>
                <p>4、在证据充分的前提下，证明医生做出的明显有悖于医疗常规或伦理的行为；</p>
                <p>5、医生私自委托不具备相应执业资格者代为完成服务；</p>
                <p>6、医生在订单外，以明示/暗示等各种方式向用户索要钱物；</p>
                <p>7、医生在服务过程中，存在明显的玩忽职守、隐瞒欺诈行为；</p>
                <p>8、用户对医生的服务不满意（评价
                    <2.5星）。</p>
            </section>
        </section>
        <hr class="division-border" />
        <section class="swift-user-content">
            <h3 class="insurance_h3">保费详情</h3>
            <section class="insurance_details">
                <p>保费：每张订单的服务费*0.5%，保险买后不退。</p>
            </section>
        </section>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less"> 
    .division-border {
        height: 12px;
        background-color: #eee;
        border: 0;
    }
    
    .textIndext {
        text-indent: 2em;
    }
    
    .swift-user {
        .swift-user-content:last-child {
            border-bottom: 0;
        }
        .swift-user-content {
            padding-left: 15px;
            padding-right: 15px;
            border-bottom: 1px solid #e0e0e0;
            .insurance_h3 {
                line-height: 55px;
                font-size: 16px;
                color: #757575;
                border-bottom: 1px solid #e0e0e0;
            }
            .hurtDanger_list {
                padding: 15px 0 10px;
                overflow: hidden;
                li {
                    float: left;
                    margin: 0 10px 5px 5px;
                    padding: 1px 13px;
                    font-size: 16px;
                    color: #b73265;
                    border: 1px solid #b73265;
                }
            }
            .insurance_details {
                padding: 10px 0 30px;
                p {
                    line-height: 24px;
                    font-size: 16px;
                    color: #212121;
                }
            }
        }
    }
</style>