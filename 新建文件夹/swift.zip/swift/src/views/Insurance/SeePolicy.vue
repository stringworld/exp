<template>
    <section class="swift-yawp">
        <section class="plr15 borderBottom">
            <h3 class="insurance_h3">投保信息 <img src="../../assets/img/Insurance-logo.png" align="right"></h3>
            <ul class="insurance_nav">
                <li>
                    <span>承保方：</span>
                    <strong>人保深圳分公司</strong>
                </li>
                <li>
                    <span>承保人：</span>
                    <strong>{{load.policy.policyName}}</strong>
                </li>
                <li>
                    <span>身份证：</span>
                    <strong>{{load.policy.idCard}}</strong>
                </li>
                <li>
                    <span>保单号：</span>
                    <strong>{{load.policy.abstractId}}</strong>
                </li>
                <li>
                    <span>联系方式：</span>
                    <strong>{{load.policy.contactPhone}}</strong>
                </li>
            </ul>
        </section>
        <hr class="division-border" />
        <section class="plr15">
            <h3 class="insurance_h3">承保内容</h3>
            <section class="insurance_details">
                <p class="textIndext">由于因下列原因取消订单或未按照约定使用预定项目的，导致用户已经支付的预定费用无法返还。而实际产生的经济损失，按合同约定负责赔偿，赔偿上限为订单的服务费金额。原因主要为：</p>
                <p>1、医生在服务过程中谩骂、诋毁、侮辱、恶意中伤用户等行为；</p>
                <p>2、医生私自将用户相关信息直接或间接用于其他商业用途；</p>
                <p>3、医生以获利为目的，以欺骗的手段让用户进行明显不当消费行为；</p>
                <p>4、在证据充分的前提下，证明医生出的明显有悖于医疗常规或伦理的行为；</p>
                <p>5、医生私自委托不具备相应执业资格者代为完成服务；</p>
                <p>6、医生在订单外，以明示/暗示等各种方式向用户索要钱物；</p>
                <p>7、医生在服务过程中，存在明显的玩忽职守、隐瞒欺诈行为；</p>
                <p>8、用户对医生的服务不满意（评价&lt;2.5星）。</p>
            </section>
        </section>
        <hr class="division-border" />
        <section class="plr15">
            <h3 class="insurance_h3">申请赔付流程</h3>
            <section class="insurance_details">
                <p>1、关注人保财险深圳分公司官方微信号“piccsz”进行报案或拨打（18814135605）报案，电子邮箱（616792930@qq.com）；</p>
                <p>2、准备并寄送理赔材料，材料包括：</p>
                <p>①被保险人身份证复印件；</p>
                <p>②被保险人支付的预付费用或信用卡担保扣款凭证，银行卡消费明细、信用卡账单或被保险项目提供方或销售方出具的预订证明；</p>
                <p>③如被保险人因本保险合同第四条中约定的情形之一导致保险事故发生时，应提供能证明保险事故确实发生的证明材料；</p>
                <p>④投保人、被保险人所能提供的其他与确认保险事故的性质、原因、损失程度等有关的证明和资料；</p>
                <p>3、等待保险公司理赔审核；</p>
                <p>4、理赔成功。</p>
            </section>
        </section>
    </section>
</template>
<script type="text/javascript">
    export default {
        data() {
                return {
                    id: this.$route.query.id,
                    load: {
                        policy: {}
                    }
                }
            },
            created() {
                this.$http.get('/load/policy/', {
                        params: {
                            id: this.id
                        }
                    })
                    .then(({
                        data
                    }) => {
                        this.load = data.data;
                    });
            }
    }
</script>
<style lang="less" scoped rel="stylesheet/less">  
    .plr15 {
        padding-left: 15px;
        padding-right: 15px;
    }
    
    .division-border {
        height: 12px;
        background-color: #eee;
        border: 0;
    }
    
    .swift-yawp {
        .insurance_h3 {
            line-height: 55px;
            font-size: 16px;
            color: #757575;
            border-bottom: 1px solid #e0e0e0;
            img {
                max-width: 200px;
                padding: 18px 0;
                max-height: 55px;
            }
        }
        .insurance_nav {
            padding: 10px 0;
            li {
            	position: relative;
            	padding: 6px 0 6px 100px;
                line-height: 24px;
                font-size: 16px;
                text-align: right;
                overflow: hidden;
                min-height: 36px;
                span {
                	position: absolute;
                	left: 0;
                	top: 50%;
                	transform: translateY(-50%);
                    width: 85px;
                    color: #757575;
                }
                strong {
                    color: #212121;
                    font-weight: normal;
                }
            }
        }
        .insurance_details {
            padding: 10px 0 30px;
            p {
                line-height: 24px;
                font-size: 16px;
                color: #212121;
            }
        }
    }
</style>