<template>
    <section class="swift-cash">
        <section class="swift-cash-content">
            <h3 class="swift-cash-title">什么是医+代金券？</h3>
            <p>「医+代金券」（以下简称「代金券」）是由医+APP发放的具有现金抵用性质的代币。用户可使用相应的代金券来抵消部分费用。</p>
        </section>
        <section class="swift-cash-content">
            <h3 class="swift-cash-title">如何获取医+代金券？</h3>
            <p>米喜会有不定期的活动，赠送代金券代码。请关注官方微博“米喜健康中心”和官方微信 “米喜健康”。</p>
        </section>
        <section class="swift-cash-content">
            <h3 class="swift-cash-title">如何使用医+代金券？</h3>
            <p>用户在购买服务时，如果拥有符合使用条件的代金券，支付界面上将会显示 「代金券」按钮，用户可点击该按钮来查看或选择要使用的代金券。</p>
        </section>
        <section class="swift-cash-content">
            <h3 class="swift-cash-title">代金券使用常见问题</h3>
            <ul class="swift-cash-list">
                <li>
                    <strong>Q</strong>
                    <span>代金券是否可以找零？</span>
                </li>
                <li>
                    <strong>A</strong>
                    <span>代金券不可找零。</span>
                </li>
                <li>
                    <strong>Q</strong>
                    <span>为什么提示我“该代金券正在使用中” ？</span>
                </li>
                <li>
                    <strong>A</strong>
                    <span>可能由于您在上一次交易中选择了该代金券，但未完成支付。请稍候再尝试使用该券。如超过 48 小时仍无法正常使用该券，请致电客服。</span>
                </li>
                <li>
                    <strong>Q</strong>
                    <span>为什么提示我 “该代金券已过期” ？</span>
                </li>
                <li>
                    <strong>A</strong>
                    <span>可能由于您在该代金券过期时间之前选择了该券但在过期时间之后才进行支付。此时该代金券仍属于过期，不能使用。</span>
                </li>
                <li>
                    <strong>Q</strong>
                    <span>为什么我在支付界面没有看到选择代金券按钮？</span>
                </li>
                <li>
                    <strong>A</strong>
                    <span>如果您当前没有符合条件的代金券，则支付界面不会显示选择代金券按钮。</span>
                </li>
                <li>
                    <strong>Q</strong>
                    <span>为什么我拿到了代金券，但个人中心里没有显示出来？</span>
                </li>
                <li>
                    <strong>A</strong>
                    <span>请先确认您是否成功领取了代金券（领取成功后会有通知）。如确认领取，但在 “个人中心” 里没有看到该代金券，则可能由于该券被判定为非法获取，已被取消。</span>
                    <p class="swif-foot">（本软件享有对「医+代金券」的全部解释权）</p>
                </li>
            </ul>

        </section>
    </section>
</template>
<style lang="less" scoped rel="stylesheet/less">    
    .swift-cash {
        height: auto;
        color: #333;
        font-family: "微软雅黑";
        background-color: #efefef;
        .swift-cash-content:last-child {
            padding-bottom: 20px;
        }
        .swift-cash-content {
            margin: 0 auto;
            width: 90%;
            padding-top: 20px;
            .swift-cash-title {
                padding: 15px 0;
                margin-bottom: 2px;
                font-size: 16px;
                text-align: center;
                background-color: #fff;
            }
            p {
                padding: 2% 5%;
                font-size: 14px;
                background-color: #fff;
            }
            .swift-cash-list {
                padding: 5px 5%;
                background-color: #fff;
                li {
                    line-height: 24px;
                    overflow: hidden;
                    strong {
                        float: left;
                        width: 20px;
                        font-size: 14px;
                        font-weight: normal;
                    }
                    span {
                        display: block;
                        margin-left: 20px;
                        font-size: 14px;
                    }
                    .swif-foot {
                        margin: 0 auto;
                        padding: 0 0 0 20px;
                    }
                }
            }
        }
    }
</style>