<template>
    <div class="swift-call">
        <transition name="fade">
            <div class="call" v-if="page === 'call' || page === 'calling'">
                <header>
                    <img :src="personDetail.doctorPortrait" alt="">
                    <p class="name">{{personDetail.doctorName}}</p>
                </header>
                <div class="explain">
                    <p>为了您的隐私安全</p>
                    <p>将由医+平台呼叫您和用户</p>
                    <transition name="fade">
                        <div v-if="page === 'call'">
                            <input type="button" :disabled="!isCallUp" value="发起通话" @click="callUp" />
                            <p class="answer">您的接听号码是{{personDetail.userNum}}</p>
                            <a @click="changeNum" class="num">换个号码</a>
                        </div>
                    </transition>
                    <transition name="fade">
                        <input v-if="page === 'calling'" type="button" value="请等待接听..." class="waiting" />
                    </transition>
                </div>
            </div>
        </transition>
        <transition name="fade">
            <div class="change-num" v-if="page === 'changeNum'">
                <h1>请输入接听手机号</h1>
                <input type="number" v-model="answerTelNum" class="telNum">
                <input type="button" value="确认" @click="confirm">
            </div>
        </transition>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    .swift-call {
        overflow: hidden;
        .fade-enter-active, .fade-leave-active {
            transition: opacity .5s
        }
        .fade-enter, .fade-leave-active {
            opacity: 0
        }
        .basic-style{
            width: 100%;
            height: 100%;
            background: -webkit-linear-gradient(top, #3E3E50,#26263D 100%);
            text-align: center;
            p{
                text-align: center;
                font-size: 14px;
            }
            input{
                width: 80%;
                line-height: 44px;
                color: #fff;
                background: #D43E72;
                margin:20px 10%;
                border-radius: 5px;
                font-size: 16px;
            }
        }
        .call{
            .basic-style;
            header{
                height: 58%;
                img{
                    width: 100px;
                    height: 100px;
                    border-radius: 100%;
                    border: 5px solid #2C2C3C;
                    margin-top: 22%;
                }
                .name{
                    color: #fff;
                    line-height: 30px;
                    font-size: 18px;
                }
            }
            p{
                color: #83838F;
            }
            .explain{
                line-height: 30px;
                position: relative;
                .answer{
                    color: #B3B3BD;
                }
                .waiting{
                    background: #E7E6EB;
                    color: #B3B3BD;
                    position: absolute;
                    top: 52px;
                    left: 0;
                }
                a{
                    text-align: center;
                    display: block;
                }
                .num{
                    color: #BE3468;
                }
            }
        }
        .change-num{
            .basic-style;
            background: #fff;
            h1{
                text-align: center;
                margin:20px;
            }
            .telNum{
                background: #F4F3F5;
                color: #000;
                line-height: 0;
                height: 44px;
                padding-left: 10px;
            }
        }
    }
</style>
<script type="text/javascript">
    import bus from '../event.js';
    export default {
        data() {
            return {
                personDetail: {},
                page: 'call',
                answerTelNum: '',
                isCallUp: true
            }
        },
        created() {
            bus.$emit('changeTitle', '免费电话');
            this.personDetail = Object.assign({}, this.personDetail, JSON.parse(sessionStorage.getItem("callUpMsg")));
        },
        methods: {
            callUp() {
                this.isCallUp = false;
                if (this.personDetail.userNum && this.personDetail.docNum) {
                    this.$http.post('/patient/call/', this.personDetail).then(({data}) => {
                        if (data.code === 0) {
                            this.page = 'calling';
                        } else {
                            this.isCallUp = true;
                            this.$toast({
                                message: data.errorMsg,
                                duration: 2500
                            });
                        }
                    });
                } else {
                    this.$toast({
                        message: '电话号码不能为空',
                        duration: 2500
                    });
                }
            },
            changeNum() {
                this.page = 'changeNum';
                bus.$emit('changeTitle', '我的电话');
            },
            confirm() {
                if (this.answerTelNum === '') {
                    this.$toast({
                        message: '请输入手机号码',
                        duration: 2500
                    });
                } else if (/^1[34578]\d{9}$/.test(this.answerTelNum)) {
                    this.page = 'call';
                    bus.$emit('changeTitle', '免费电话');
                    this.$toast({
                        message: '手机号码填写正确',
                        duration: 2500
                    });
                    this.personDetail.userNum = this.answerTelNum.toString();
                } else {
                    this.$toast({
                        message: '手机号码有误，请重新填写',
                        duration: 2500
                    });
                }
            }
        }
    }
</script>