<template>
    <div class="swift-order-detail">
        <div v-if="!isError">
            <order-steps step="step-service" v-if="orderMsg.state === 'service'" />
            <order-steps step="step-finish" v-if="orderMsg.state === 'finish'" />
            <div class="service-msg">
                <span>医生上门服务时间</span>
                <h2 class="time">{{orderMsg.serviceTime}}</h2>
                <span class="state">{{orderMsg.serviceStateMsg}}</span>
            </div>
            <hr>
            <div class="order-operate">
                <ul class="operate">
                    <router-link tag="li" :to="{name:'chat', query:{order: orderMsg.abstractId, member: orderMsg.doctorInfo.memberId, status: orderMsg.state}}">
                        <img src="../../assets/img/icon_chat.png" alt="">
                        <h6>图文咨询</h6>
                    </router-link>
                    <li @click="telCounseling">
                        <img src="../../assets/img/icon_phone.png" alt="">
                        <h6>电话咨询</h6>
                    </li>
                    <li @click="medicalRecord">
                        <img src="../../assets/img/icon_detail.png" alt="">
                        <h6>诊疗记录</h6>
                    </li>
                </ul>
                <router-link tag="div" :to="{name:'department', query:{doctorId: orderMsg.doctorInfo.id}}" class="person-detail">
                    <img :src="orderMsg.doctorInfo.portrait">
                    <p class="detail-msg">
                        <span>{{orderMsg.doctorInfo.name}}</span>
                        <span>{{orderMsg.doctorInfo.title}}</span>
                        <span>{{orderMsg.doctorInfo.address}}</span>
                    </p>
                </router-link>
            </div>
            <div class="order-msg">
                <h2>订单信息</h2>
                <div class="person-detail">
                    <img :src="orderMsg.patientInfo.portrait">
                    <p class="detail-msg">
                        <span>{{orderMsg.patientInfo.name}}</span>
                        <span>{{orderMsg.patientInfo.phone}}</span>
                        <span>{{orderMsg.patientInfo.address}}</span>
                    </p>
                </div>
                <ul>
                    <li>
                        <i>服务项</i>
                        <em>{{orderMsg.serviceInfo.name}}</em>
                        <ul class="service-detail">
                            <li v-for="item in orderMsg.serviceInfo.serviceDetail">{{item}}</li>
                        </ul>
                    </li>
                    <li>
                        <i>服务项价格</i>
                        <em>{{orderMsg.serviceInfo.price}}</em>
                    </li>
                    <li>
                        <i>订单编号</i>
                        <em>{{orderMsg.abstractId}}</em>
                    </li>
                </ul>
                <h2>支付信息</h2>
                <ul>
                    <li>
                        <i>支付方式</i>
                        <em>{{orderMsg.payInfo.method}}</em>
                    </li>
                    <li>
                        <i>订单总额</i>
                        <em>{{orderMsg.payInfo.orderPrice}}</em>
                    </li>
                    <li>
                        <i>实付金额</i>
                        <em>{{orderMsg.payInfo.actualPayAmount}}</em>
                    </li>
                </ul>
                <h2 v-if="orderMsg.insuranceList && orderMsg.insuranceList.length">服务保障</h2>
                <ul>
                    <li v-for="item in orderMsg.insuranceList">
                        <i :class="{presentation: item.hasFree}"><router-link to="/UserDissatisfied">{{item.name}}</router-link></i>
                        <em class="assurance"><router-link :to="{name:'seePolicy', query:{id: item.id}}">查看保单</router-link></em>
                    </li>
                </ul>
            </div>
            <hr>
        </div>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import 'orderDetail.less';
</style>
<script type="text/javascript">
    import OrderSteps from '../../components/OrderSteps';
    import bus from 'src/event.js';
    import { Toast } from 'mint-ui';
    import wxinit from 'src/wxinit';
    export default {
        components: {
            OrderSteps
        },
        data() {
            return {
                orderMsg: {},
                isError: true,
                callupData: {},
            }
        },
        created() {
            this.getData();
        },
        methods: {
            telCounseling() {
                if (this.orderMsg.state === 'service') {
                    this.callupData = {
                        doctorName: this.orderMsg.doctorInfo.name,
                        doctorPortrait: this.orderMsg.doctorInfo.portrait,
                        docNum: this.orderMsg.doctorInfo.phone,
                        userName: this.orderMsg.patientInfo.name,
                        userNum: this.orderMsg.patientInfo.phone,
                        abstractId: this.orderMsg.abstractId
                    }
                    sessionStorage.setItem("callUpMsg", JSON.stringify(this.callupData));
                    this.$router.push({ path: '/callup' });
                } else {
                    this.callToast = Toast({
                        message: '服务已完成',
                        duration: 2500
                    });
                    this.recordToast.close();
                }
            },
            medicalRecord() {
                if (this.orderMsg.hasDiagnosisRecord) {
                    this.$router.push({ name: 'view', query: { id: this.orderMsg.diagnosisRecordId } });
                } else {
                    this.recordToast = Toast({
                        message: '医生还没有填写诊疗记录',
                        duration: 2500
                    });
                    this.callToast.close();
                }
            },
            getData() {
                bus.$emit('indicatorShow');
                if (this.$route.query.abstractid) {
                    this.$http.get('/patient/order/detail/', { params: { abstractId: this.$route.query.abstractid } }).then(({data}) => {
                        bus.$emit('indicatorHide');
                        if (data.code === 0) {
                            this.orderMsg = Object.assign({}, this.orderMsg, data.data);
                            this.isError = false;
                            const share = {
                                title: '上门服务', // 分享标题
                                link: 'https://p3.thedoc.cn/h5/activity/addService/smfw_B2.html?id=100005&housecall_d', // 分享链接
                                imgUrl: 'https://upyun.thedoc.cn/cdn/addService/icon/door_service_icon.png', // 分享图标
                                desc: '专业医护上门检测/查指导',
                                success: function () { },
                                cancel: function () { }
                            }
                            wxinit(['onMenuShareTimeline', 'onMenuShareAppMessage']);
                            wx.ready(function () {
                                wx.onMenuShareTimeline(share);
                                wx.onMenuShareAppMessage(share);
                            });
                        } else {
                            this.$toast({
                                message: data.errorMsg,
                                duration: 2500
                            });
                        }
                    })
                } else {
                    bus.$emit('indicatorHide');
                    this.$router.push({ path: '/order/notexist' });
                }
            }
        }
    }
</script>