<template>
    <div>
        <tab :datasource="datasource" :current="current" v-on:change="changeTab" />
        <div class="tab-content-container">
            <order-list :orderList="currentList" />
        </div>
    </div>
</template>

<style lang="less" scoped rel="stylesheet/less">
    @import './serviceOrder.less';
</style>

<script type="text/javascript">
    import tab from '../../components/Tab';
    import orderList from './orderList';
    import Enum from 'enum';
    import bus from 'src/event';
    import spinner from 'vue-spinner/src/RotateLoader';
    import { MessageBox } from 'mint-ui';

    const status = new Enum([
        { name: 'PENDING', value: 'pending', text: '待处理' },
        { name: 'PROCESSING', value: 'processing', text: '服务中' },
        { name: 'END', value: 'end', text: '已完成' }
    ]);

    export default {
        components: {
            tab,
            orderList,
            spinner
        },
        data() {
            return {
                changeTitle: '订单',
                listMap: {},
                orderStatus: status,
                current: sessionStorage.getItem("current") || status.PENDING
            }
        },
        route: {
            data() { }
        },
        computed: {
            datasource() {
                return this.orderStatus.toArray();
            },
            currentList() {
                return this.listMap[this.current] || [];
            }
        },
        created() {
            bus.$emit('indicatorShow');
            //   bus.$emit('changeTitle',this.changeTitle);
            const getOrderList = (status) => {
                return this.$http.get('/patient/order/list/', {
                    params: {
                        status: status
                    }
                }).then(({ data }) => {
                    bus.$emit('indicatorHide');
                    if (!data.code) {
                        return data.data;
                    } else {
                        MessageBox('提示', data.errorMsg);
                    }
                    return [];
                });
            }
            const paramsName = 'abstractid';
            this.datasource.forEach(item => {
                //路由 "router://orderdetail?abstractid=111068"
                getOrderList(item.name).then(data => {
                    let list = data.map((item, index) => {
                        const path = item.jumpLink.replace(/^router:\//, '');
                        const router = this.$router.resolve(path).resolved;
                        return {
                            ...item,
                            router: router.path,
                            paramsName,
                            abstractId: router.query[paramsName]
                        }
                    });
                    this.listMap = { ...this.listMap, [item.value]: list };
                });
            })
        },
        methods: {
            changeTab(current) {
                sessionStorage.setItem("current", current);
                this.current = current;
            }
        }
    }
</script>