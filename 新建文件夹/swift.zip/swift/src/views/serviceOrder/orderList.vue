<template>
    <ul class="order-list" v-if="orderList.length">
        <li @click="goTo(item.router,item.paramsName,item.abstractId)" v-for="(item,index) in orderList">
            <p>
                <span class="server-status" :style="{backgroundColor:item.serveTypeColor}">{{item.serveType}}</span>
                <span class="time">{{item.date}}</span>
            </p>
            <p>{{item.title}}</p>
            <p>{{item.orderDesc}}</p>
        </li>
    </ul>
    <div class="swift-order-content" v-else>
        <img src="../../assets/img/img_order@2x.png" />
        <p>暂无订单</p>
    </div>
</template>

<script>
    export default {
        props: ['orderList'],
        methods: {
            goTo(router, paramsName, abstractId) {
                this.$router.push({ path: router, query: { [paramsName]: abstractId } });
            }
        }
    }
</script>

<style lang="less" scoped rel="stylesheet/less">
    @pDefault: #9B9B9B;
    @docTitle: #4A4A4A;
    
    .order-list {
        li {
            width: 100%;
            height: 87px;
            list-style-type: none;
            background-color: #fff;
            padding: 5px 0 0 4%;
            border-bottom: 1px solid #dddddd;
            &:nth-last-child(1) {
                border-bottom: 0;
            }
            .server-status {
                width: 32px;
                height: 18px;
                line-height: 18px;
                border-radius: 5px;
                text-align: center;
                display: inline-block;
                color: #fff;
                font-size: 12px;
                margin-right: 5px;
                opacity: .75;
            }
            .time {
                font-size: 12px;
            }
            p {
                width: 100%;
                height: 25px;
                line-height: 25px;
                font-size: 15px;
                color: @pDefault;
                &:nth-child(2) {
                    color: @docTitle !important;
                }
            }
        }
    }
    .swift-order-content {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 200px;
        height: 100px;
        transform: translate(-50%,-50%);
        text-align: center;
        p {
            padding-top: 10px;
            font-size: 18px;
            color: #B3B3BD;
            text-align: center;
            letter-spacing: 2px;
        }
        img {
            display: block;
            width: 60px;
            margin: 0 auto;
        }
    }
</style>