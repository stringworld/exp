<template>
    <div class="swift-report-view" v-if="!isError">
        <div class="medical-record">
            <h2>诊疗记录</h2>
            <pre class="description">{{orderDetailData.description || "无"}}</pre>
            <h2>相关图片</h2>
            <ul class="correlation-img">
                <li v-if="orderDetailData.caseLabelList && orderDetailData.caseLabelList.length" v-for="item in orderDetailData.caseLabelList"
                    @click.stop="photoPreview(item)">
                    <p :style="{'padding-bottom': '100%', 'background':'url('+item.imgUrl+') no-repeat center', 'background-size': 'cover'}"></p>
                    <span class="tag">{{item.tagText}}</span>
                </li>
                <li v-if="!(orderDetailData.caseLabelList && orderDetailData.caseLabelList.length)" class="nopicTip">
                    无相关图片
                </li>
            </ul>
        </div>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    .swift-report-view {
        background: #F5F5F5;
        .medical-record {
            h2 {
                font-size: 14px;
                line-height: 45px;
                padding-left: 15px;
                color: #83838F;
            }
            .description {
                font-size: 14px;
                border: none;
                width: 100%;
                padding: 15px;
                white-space: pre-wrap;
                background: #fff;
                color: #52525C;
                word-break: break-all;
            }
            .correlation-img {
                padding: 11px 15px 4px;
                margin: 0 -4px;
                overflow: hidden;
                background: #fff;
                li {
                    width: 33.33%;
                    display: inline-block;
                    box-sizing: border-box;
                    float: left;
                    border: 4px solid #fff;
                    text-align: center;
                    .little-img {
                        padding-bottom: 100%;
                    }
                    .tag {
                        line-height: 30px;
                        color: #83838F;
                    }
                    &.nopicTip {
                        text-align: left;
                    }
                }
            }
        }
    }
</style>
<script type="text/javascript">
    import spinner from 'vue-spinner/src/RotateLoader';
    import wxinit from 'src/wxinit';
    import bus from 'src/event.js';
    export default{
        components: {
            spinner
        },
        data(){
            return {
                orderDetailData: {},
                images: [],
                isError: true,
                isLoading: true
            }
        },
        created () {
            wxinit(['previewImage']);
            this.getData();
        },
        methods: {
            photoPreview(item) {
                wx.previewImage({
                    current: item.imgUrl,
                    urls: this.images
                })
            },
            getData() {
                bus.$emit('indicatorShow')
                this.$http.get('/load/diagnosis/record/',{params:{id:this.$route.query.id}}).then(({data}) => {
                    bus.$emit('indicatorHide')
                    if(data.code === 0){
                        this.isError = false;
                        this.orderDetailData = Object.assign({}, this.orderDetailData, data.data);
                        this.images = this.orderDetailData.caseLabelList.map(item => item.imgUrl);
                    }else{
                        this.$toast({
                            message: data.errorMsg,
                            duration: 2500
                        });
                    }
                });
            }
        }
    }
</script>
