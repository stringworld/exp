/**
 * Created by zhouhua on 2017/1/11.
 */
import Vue from 'vue';
import Moment from 'moment';
import 'moment/locale/zh-cn';
Moment.locale('zh-cn');

Vue.filter('datetime', function (timestamp, format) {
    const date = Moment(timestamp);
    if (!format) {
        const now = Moment();
        if (now.year() !== date.year()) {
            format = 'YYYY年MM月DD日 HH:mm';
        }
        else if (now.week() !== date.week()) {
            format = 'MM月DD日 HH:mm';
        }
        else if (now.day() !== date.day()) {
            format = 'dddd HH:mm';
        }
        else {
            format = 'HH:mm';
        }
    }
    return date.format(format);

});

