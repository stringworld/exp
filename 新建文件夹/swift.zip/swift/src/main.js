// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'vconsole';
import './assets/css/base.css'
import 'normalize.css';
import 'animate.css';
import './assets/css/style.css';
import 'vue-toast-mobile/lib/index.css';
import 'es6-promise/auto'; // polyfill for Promise. Axios maybe need this.
import Vue from 'vue';
import Mint from 'mint-ui';
import 'mint-ui/lib/style.css';
import axios from 'axios';
import App from './App';
import router from './routes/index';
import fastclick from 'fastclick';
import AlloyFinger from 'alloyfinger';
import AlloyFingerVue from 'alloyfinger/vue/alloy_finger.vue';
import './filters/index';
import wxinit from 'src/wxinit';
import VueCookies from 'vue-cookies';

wxinit([]);
wx.ready(function() {
    wx.hideOptionMenu();
})

// add Raven to monitor app status
// import Raven from 'raven-js';
// import RavenVue from 'raven-js/plugins/vue';
// Raven.config('https://96f082449c0841afb5445bd42d35106c@sentry.io/123576')
//     .addPlugin(RavenVue, Vue)
//     .install();

// remove click delays on touch devices.
fastclick.attach(document.body);
Vue.use(AlloyFingerVue, { AlloyFinger });

//api https://www.npmjs.com/package/vue-cookies
Vue.use(VueCookies);

/* eslint-disable no-new */
Vue.prototype.$http = axios;
Vue.use(Mint);
new Vue({
    el: '#app',
    router,
    ...App
});
