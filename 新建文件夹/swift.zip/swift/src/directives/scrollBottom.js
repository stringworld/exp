'use strict';

var Vue = require('vue');

var compatible = (/^2\./).test(Vue.version);
if (!compatible) {
  Vue.util.warn(' only supports Vue 2.x, and does not support Vue ' + Vue.version);
}

var scrollBottom = {
    isFn: true, // important!
    bind: function (el, binding) {
        alert(1)
        //el.style.backgroundColor='#fff'
    },
    update: function (handler) {
        // the passed in value is a function
    },
    unbind: function () {
        // ...
    }
};



exports.scrollBottom = scrollBottom;
