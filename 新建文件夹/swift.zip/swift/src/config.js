/**
 * Created by zhouhua on 2017/1/2.
 */
import Enum from 'enum';
const config = {};
config.wss = 'ws://chat.thedoc.cn/chat';
config.debugWeixinSdk = false;
config.apiRoot = '';
config.apis = {
    initWxApi: '/wechat/jsapi/',
    getUid: '/zebra/snowflake/',
    createChatOrder: '/generate/chat/order/',
    uploadWxImage: '/upload/wximg/',
    clinicDetail: '/doctor/clinic/',
    amr2mp3: '/zebra/amrtomp3/'
};

config.MessageType = new Enum([
    {name: 'text', value: '1'},
    {name: 'image', value: '2'},
    {name: 'voice', value: '3'}
]);

Object.keys(config.apis).forEach(key => {
    config.apis[key] = `${config.apiRoot}${config.apis[key]}`;
});

export default config;
