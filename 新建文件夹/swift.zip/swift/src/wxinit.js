/**
 * Created by zhouhua on 2017/1/3.
 */
import $http from 'axios';
import config from './config';
import { MessageBox } from 'mint-ui';
export default function(apis) {
    $http.get(config.apis.initWxApi, { params: { url: window.location.href.split('#')[0] } }).then(({ data }) => {
        const params = {
            debug: config.debugWeixinSdk,
            appId: data.data.appid,
            timestamp: data.data.timestamp,
            nonceStr: data.data.nonceStr,
            signature: data.data.signature,
            jsApiList: [...apis, 'hideOptionMenu', 'onMenuShareTimeline', 'onMenuShareAppMessage']
        };
        wx.config(params);
        wx.ready(() => {
            wx.checkJsApi({
                jsApiList: apis,
                success({ checkResult }) {
                    if (checkResult) {
                        if (!Object.keys(checkResult).every(key => {
                            if(key === 'onVoiceRecordEnd') {
                                return true;
                            }
                            return checkResult[key] === 'yes' || checkResult[key] === true;
                        })) {
                            MessageBox("请使用手机端微信");
                        }
                    }
                }
            });
        });
    });
}
