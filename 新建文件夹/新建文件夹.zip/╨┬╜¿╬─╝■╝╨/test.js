const parse5 = require('parse5');
const fs = require('fs');
const path = require('path');

const parse = parse5.parseFragment;
const serializer = parse5.serialize;
const treeAdapter = parse5.treeAdapters.default;
const fromPath = path.resolve(__dirname, 'src');
const toPath = path.resolve(__dirname, 'sonar_test');
function checkLang(node) {
    if (node.attrs) {
        var i = node.attrs.length;
        while (i--) {
            var attr = node.attrs[i];
            if (attr.name === 'lang') {
                return attr.value
            }
        }
    }
}
function serializeTemplate(node) {
    const treeAdapter = parse5.treeAdapters.default;
    const docFragment = treeAdapter.createDocumentFragment();
    treeAdapter.appendChild(docFragment, node);
    return serializer(docFragment);
}
function translate(p) {
    fs.readdir(p, function (err, files) {
        files.forEach(function (file) {
            var newPath = path.join(p, file)
            fs.stat(newPath, function (err, result) {
                if (result.isFile()) {
                    if (/\.spec\.js$/.test(newPath)) {
                        return;
                    }
                    var pathObj = path.parse(newPath);
                    if (pathObj.ext === '.vue') {
                        fs.readFile(newPath, function (err, content) {
                            const fragment = parse(content.toString());
                            let ext;
                            let target = newPath.replace(fromPath, toPath);
                            fragment.childNodes.forEach(node => {
                                switch (node.nodeName) {
                                    case 'template':
                                        ext = checkLang(node) || 'html';
                                        fs.writeFile(target.replace('.vue', `.${ext}`), serializeTemplate(node), () => {
                                        });
                                        break;
                                    case 'style':
                                        ext = checkLang(node) || 'css';
                                        fs.writeFile(target.replace('.vue', `.${ext}`), serializer(node), () => {
                                        });
                                        break;
                                    case 'script':
                                        ext = checkLang(node) || 'js';
                                        fs.writeFile(target.replace('.vue', `.${ext}`), serializer(node), () => {
                                        });
                                        break;
                                }
                            });
                        });
                    }
                }
                else if (result.isDirectory()) {
                    fs.mkdir(newPath.replace(fromPath, toPath), function () {
                        translate(newPath);
                    });
                }
            })
        });
    });
}

translate(fromPath);
