/**
 * Created by zhouhua on 2017/2/7.
 */

import Hello from 'src/views/Hello';
import Vue from 'vue';

describe('Hello.vue', () => {
    it('should render correct contents', () => {
        const vm = new Vue({
            el: document.createElement('div'),
            render: h => <Hello/>
        });
        expect(vm.$el.innerText).to.equal('hello world');
    });
});
