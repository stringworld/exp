import vm from 'src/main';
import App from 'src/App';

describe('main.js', () => {
    it('should render correct contents', () => {
        expect(vm.$el.id).to.equal('app');
    });
    it('test data', () => {
        expect(vm.enterActiveClass).to.equal('animated fadeIn');
    });
});
describe('App.vue', () => {
    it('data is a function', () => {
        expect(App.data).to.be.a('function');
    });
});
