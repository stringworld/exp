var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "type": "JSONDoctor",
        "data": {
            "doctor": [{
                "specialty": [{
                    "name": "偏头痛",
                    "tags": "",
                    "description": "",
                    "path": "0,1001",
                    "parentId": "1001",
                    "layer": 2,
                    "id": "1032"
                }],
                "created": 1477365820000,
                "updated": 1477568710000,
                "hospitalId": "1367",
                "provinceName": "上海",
                "memberId": "com.medishare.manis.domain.member.Doctor_102972",
                "portrait": "http://192.168.10.213:8082/img/992e574b-1eec-45ab-8ed9-c4a564bd3ce4.png",
                "cityId": "75",
                "username": "186524618748",
                "provinceId": "2",
                "isCertified": "0",
                "schoolCityName": "市辖区",
                "inService": true,
                "joinStatus": "0",
                "realname": "李晓雪",
                "schoolName": "上海复旦",
                "townId": "5562",
                "pushKey": "a7ee0d197fa4c2ec179d937fb2e9b45b7c3658d1",
                "schoolCityId": "75",
                "districtId": "790",
                "townName": "四川北路街道",
                "id": "102972",
                "gender": "女",
                "cityName": "上海市",
                "schoolProvinceName": "上海",
                "department": {
                    "parentId": "484",
                    "templateId": "总",
                    "id": "502",
                    "name": "中医骨伤科"
                },
                "unReadNum": 0,
                "schoolId": "10002",
                "departmentId": "502",
                "districtName": "虹口区",
                "qrcode": "http://192.168.10.215:8082/qr/doctor/102972",
                "schoolProvinceId": "2",
                "hospitalName": "四川北路街道社区卫生服务中心",
                "doctorType": "全科医生"
            }]
        },
        "isSuccess": true
    })
}
module.exports = data;