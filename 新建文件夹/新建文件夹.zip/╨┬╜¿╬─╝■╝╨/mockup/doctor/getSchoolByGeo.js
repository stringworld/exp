var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "data": {
            "list": [{
                    "id": "10001",
                    "name": "上海交大",
                    "provinceId": "2",
                    "provinceName": "上海",
                    "cityId": "75",
                    "cityName": "市辖区",
                    "address": "上海市徐汇区龙阳路25号"
                },
                {
                    "id": "10002",
                    "name": "上海复旦",
                    "provinceId": "2",
                    "provinceName": "上海",
                    "cityId": "75",
                    "cityName": "市辖区",
                    "address": "上海市徐汇区龙阳路25号"
                }
            ]
        },
        "type": "JSONDoctor"
    });
};
module.exports = data;