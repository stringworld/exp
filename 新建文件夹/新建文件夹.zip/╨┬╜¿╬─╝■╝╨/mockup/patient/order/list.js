﻿var Mock = require('mockjs');
var pool = [{
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "01-11 11:19",
        "jumpLink": "router://ConfirmOrder?abstractid=111128"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-26 19:22",
        "jumpLink": "router://ConfirmOrder?abstractid=111148"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-26 19:18",
        "jumpLink": "router://ConfirmOrder?abstractid=111147"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-26 19:16",
        "jumpLink": "router://ConfirmOrder?abstractid=111146"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-26 18:58",
        "jumpLink": "router://ConfirmOrder?abstractid=111144"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 18:22",
        "jumpLink": "router://ConfirmOrder?abstractid=111133"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 18:09",
        "jumpLink": "router://ConfirmOrder?abstractid=111130"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 18:06",
        "jumpLink": "router://ConfirmOrder?abstractid=111129"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:47",
        "jumpLink": "router://ConfirmOrder?abstractid=111121"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:41",
        "jumpLink": "router://ConfirmOrder?abstractid=111119"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:39",
        "jumpLink": "router://ConfirmOrder?abstractid=111117"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:34",
        "jumpLink": "router://ConfirmOrder?abstractid=111116"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:32",
        "jumpLink": "router://ConfirmOrder?abstractid=111115"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:30",
        "jumpLink": "router://ConfirmOrder?abstractid=111114"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:27",
        "jumpLink": "router://ConfirmOrder?abstractid=111113"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:22",
        "jumpLink": "router://ConfirmOrder?abstractid=111112"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:16",
        "jumpLink": "router://ConfirmOrder?abstractid=111110"
    },
    {
        "serveType": "上门",
        "serveTypeColor": "#F39A0D",
        "title": "上门服务-007",
        "orderDesc": "您已申请，请等待医生服务。",
        "date": "12-23 16:07",
        "jumpLink": "router://ConfirmOrder?abstractid=111109"
    }
];
var data = function() {
    var list = [];
    var l = pool.length;
    for (var i = 10; i > 0; i--) {
        list.push(pool[Math.floor(Math.random() * l)]);
    }
    return Mock.mock({
        "code": 0,
        "serialID": null,
        "data": list,
        "errorMsg": null,
        "pager": null
    })
}
module.exports = data;