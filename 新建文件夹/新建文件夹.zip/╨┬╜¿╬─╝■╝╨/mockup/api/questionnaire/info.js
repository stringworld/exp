var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": {
            "questionnaireId": "100665",
            "questionnaireName": "问卷1",
            "questions": [{
                "questionId": "100665",
                "questionNum": "Q1",
                "questionName": "请问您是xx社区卫生服务中心的叔叔/阿姨吗？",
                "type": "0",
                "answerContent": [{"key": "1", "value": "是"}, {"key": "2", "value": "否"}]
            }, {
                "questionId": "100666",
                "questionNum": "Q2",
                "questionName": "请问您的家庭医生是xx社区卫生服务中心的xx医生吗？",
                "type": "0",
                "answerContent": [{"key": "1", "value": "是"}, {"key": "2", "value": "否"}]
            }, {
                "questionId": "100667",
                "questionNum": "Q3",
                "questionName": "如果您有健康问题，是否会优先到您的家庭医生处就诊或咨询吗？",
                "type": "0",
                "answerContent": [{"key": "1", "value": "是"}, {"key": "2", "value": "否"}]
            }, {
                "questionId": "100668",
                "questionNum": "Q4",
                "questionName": "请问您对社区卫生服务中心内，您的家庭医生就医服务是否满意？",
                "type": "0",
                "answerContent": [{"key": "1", "value": "满意"}, {"key": "2", "value": "一般"}, {
                    "key": "3",
                    "value": "不满意"
                }]
            }, {
                "questionId": "100669",
                "questionNum": "Q5",
                "questionName": "请问您对您的家庭医生就医服务有其他意见或者建议吗？",
                "type": "1",
                "answerContent": [{"key": "1", "value": "药品种类少"}, {"key": "2", "value": "医生提升服务意识"}, {
                    "key": "3",
                    "value": "提供上门服务难"
                }, {"key": "4", "value": "签约医生调整"}, {"key": "5", "value": "无建议"}, {
                    "key": "6",
                    "value": "社区医院配药难"
                }, {"key": "7", "value": "社区医院看病难"}, {"key": "8", "value": "要表扬"}, {"key": "9", "value": "其他"}]
            }, {
                "questionId": "100670",
                "questionNum": "Q6",
                "questionName": "核实文化程度",
                "type": "0",
                "answerContent": [{"key": "1", "value": "文盲及半文盲"}, {"key": "2", "value": "小学"}, {
                    "key": "3",
                    "value": "初中"
                }, {"key": "4", "value": "高中"}, {"key": "5", "value": "技工学校"}, {
                    "key": "6",
                    "value": "中等专科学校"
                }, {"key": "7", "value": "大学专科和专科学校"}, {"key": "8", "value": "大学本科"}, {
                    "key": "9",
                    "value": "研究生"
                }, {"key": "10", "value": "研究生以上"}, {"key": "11", "value": "不详"}]
            }]
        }
    })
}
module.exports = data;