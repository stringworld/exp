var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "code": 0,
        "data": {
            "contactName": "杰哥",
            "couponId": "测试内容xv5i",
            "hasCoupon": true,
            "homeAddress": "上海上海市黄浦区南京东路街道测试",
            "insuranceList": [{
                "hasFree": true,
                "id": "1",
                "introduceUrl": "http://mylxx.ngrok.cc/html/serveYawp/",
                "name": "用户不满意险",
                "payAmount": 0
            }],
            "serviceAmount": "7632.0元",
            "serviceDetail": [
                "上门基本服务",
                "输液与肌肉注射"
            ],
            "serviceDoctor": "007",
            "serviceName": "上门服务",
            "serviceTime": "11-06 10:49"
        },
        "errorMsg": 1,
        "pager": 1,
        "serialID": 1
    })
}
module.exports = data;