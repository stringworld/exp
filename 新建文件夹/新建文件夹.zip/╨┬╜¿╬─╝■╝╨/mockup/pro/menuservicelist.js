var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [{
            "logoPath": "http://192.168.10.215/images/footer_logo.png",
            "name": "上门服务上门服务上门服务上门服务上门服务",
            "id": "1",
            "serviceMessage": "http://192.168.10.215/images/footer_logo.png"
        },
            {
                "logoPath": "http://192.168.10.215/images/footer_logo.png",
                "name": "慢病管理",
                "id": "2",
                "serviceMessage": "http://192.168.10.215/images/footer_logo.png"
            },
            {
                "logoPath": "http://192.168.10.215/images/footer_logo.png",
                "name": "私家医生",
                "id": "3",
                "serviceMessage": "http://192.168.10.215/images/footer_logo.png"
            }]
    });
};
module.exports = data;