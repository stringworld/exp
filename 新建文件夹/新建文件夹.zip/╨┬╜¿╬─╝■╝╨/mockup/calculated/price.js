var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "code": 0,
        "data": {
            "couponText": "已减免99.0元",
            "price": "381.0"
        },
        "errorMsg": 1,
        "pager": 1,
        "serialID": 1
    })
}
module.exports = data;