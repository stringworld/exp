var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
            "code": 0,
            "data": [{
                "id": "1",
                "contentText": "这篇文章好啊！",
                "userId": "1",
                "userName": "张三",
                "contentDate": "2016-10-21 11:42"
            }, {
                "id": "2",
                "contentText": "嗯，是很好！",
                "userId": "2",
                "userName": "李四",
                "contentDate": "2016-10-21 11:42",
                "toUserId": "1",
                "toUserName": "张三"
            }, {
                "id": "3",
                "contentText": "嗯！",
                "userId": "1",
                "userName": "张三",
                "contentDate": "2016-10-21 11:45",
                "toUserId": "2",
                "toUserName": "李四"
            }, {
                "id": "4",
                "contentText": "这文章还行！",
                "userId": "4",
                "userName": "溜溜",
                "contentDate": "2016-10-21 17:08"
            }, {
                "id": "5",
                "contentText": "是的！",
                "userId": "3",
                "userName": "王五",
                "contentDate": "2016-10-21 17:10",
                "toUserId": "2",
                "toUserName": "李四"
            }, {
                "id": "100394",
                "contentText": "还行。",
                "userId": "1",
                "userName": "张三",
                "contentDate": "2016-10-21 18:53",
                "toUserId": "4",
                "toUserName": "溜溜"
            }, {
                "id": "6",
                "contentText": "你认真看了吗？我感觉不怎么样.",
                "userId": "4",
                "userName": "琪琪",
                "contentDate": "2016-10-21 18:55",
                "toUserId": "4",
                "toUserName": "溜溜"
            }, {
                "id": "100405",
                "contentText": "",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-03 16:25",
                "toUserId": "100200",
                "toUserName": "姚怀广"
            }, {
                "id": "100406",
                "contentText": "兵者，国之大事，死生之地，存亡之道，不可不察也。",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-03 16:26",
                "toUserId": "100200",
                "toUserName": "姚怀广"
            }, {
                "id": "100407",
                "contentText": "兵者，国之大事，死生之地，存亡之道，不可不察也。",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-03 16:27",
                "toUserId": "100200",
                "toUserName": "姚怀广"
            }, {
                "id": "100408",
                "contentText": "兵者，国之大事，死生之地，存亡之道，不可不察也。",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-03 17:24",
                "toUserId": "100200",
                "toUserName": "姚怀广"
            }, {
                "id": "100409",
                "contentText": "兵者，国之大事，死生之地，存亡之道，不可不察也。",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-03 18:00",
                "toUserId": "100200",
                "toUserName": "姚怀广"
            }, {
                "id": "100410",
                "contentText": "大大大大大",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 22:34"
            }, {
                "id": "100411",
                "contentText": "",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:03"
            }, {
                "id": "100412",
                "contentText": "",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:04"
            }, {
                "id": "100413",
                "contentText": "",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:05",
                "toUserId": "4",
                "toUserName": "琪琪"
            }, {
                "id": "100414",
                "contentText": "dadadada",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:07"
            }, {
                "id": "100415",
                "contentText": "dadadadadadadad",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:08",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100416",
                "contentText": "得与王子同舟",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-05 23:09",
                "toUserId": "4",
                "toUserName": "琪琪"
            }, {
                "id": "100417",
                "contentText": "aa",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 11:13"
            }, {
                "id": "100418",
                "contentText": "dadadadada",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 16:34",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100419",
                "contentText": "dadadada",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 16:39",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100420",
                "contentText": "hehe",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 16:45",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100421",
                "contentText": "山有木兮木有枝",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 16:47",
                "toUserId": "1",
                "toUserName": "张三"
            }, {
                "id": "100422",
                "contentText": "dadadadadadadada",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-06 16:49",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100423",
                "contentText": "山海不可平",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-07 14:40"
            }, {
                "id": "100424",
                "contentText": "所爱隔山海",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-07 14:44"
            }, {
                "id": "100425",
                "contentText": "山海不可平",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-07 14:45"
            }, {
                "id": "100426",
                "contentText": "\"山海不可平\"",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-07 15:20",
                "toUserId": "100357",
                "toUserName": "姚怀广"
            }, {
                "id": "100432",
                "contentText": "dadadadadadad",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-07 16:06"
            }, {
                "id": "100433",
                "contentText": "share_receiptApi.userid",
                "userId": "100357",
                "userName": "姚怀广",
                "contentDate": "2016-11-08 13:46"
            }]
        }
    )
}
module.exports = data;