var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": {
            "id": "100395",
            "releaseId": "100357",
            "releaseName": "姚怀广",
            "status": "0",
            "statusName": "置顶",
            "title": "协协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协",
            "type": "1",
            "label": ["散文", "医疗", "武汉"],
            "content": "正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文",
            "contentImg": ["http://192.168.10.215:8082/download/img/b3c00ae3-35e6-4296-8f66-b1c17f4e02dc.jpg_800", "http://192.168.10.215:8082/download/img/a3895ba7-32e0-473d-9eba-e9857763e9f6.jpg_800", "http://192.168.10.215:8082/download/img/a3895ba7-32e0-473d-9eba-e9857763e9f6.jpg_800"],
            "created": "2016-10-24 10:49",
            "auditCount": "8",
            "replyCount": "84",
            "portrait": "http://192.168.10.215:8082/img/e3be7173-2841-4a7f-998b-fa69b9908dec.png",
            "checkRouter": "router://communityWebview?url=http%3A%2F%2F192.168.10.214%3A8008%2Fant%2Fptm.html%23%2Fauditlist%3Ftopicid%3D100395&topicid=100395",
            "shareTitle": "协协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协作1协",
            "shareContent": "正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文正文",
            "shareIcon": "http://192.168.10.215:8082/download/img/b3c00ae3-35e6-4296-8f66-b1c17f4e02dc.jpg_800",
            "shareUrl": "http://192.168.10.214:8008/ant/ptm.html#/topicdetail?topicid=100395&shareUrl",
            "commentatorId": "100357",
            "commentatorName": "姚怀广",
            "topicStatus": "PROCESSING",
            "isOwner": true
        }
    })
}
module.exports = data;