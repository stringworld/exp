# vue-project

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install
# init git submodule
sh init.sh

# serve with hot reload at localhost:8080
npm run server

# build for production with minification
npm run build
```

## Test

## Running unit test:

First of all, run:
```bash
npm run test
```

Then you can explore `test/unit/coverage/lcov-report/index.html` to check coverage detail.

## Running Sonar scanner

Just running:

```bash
sh test.sh
```

Then, check this: [sonar dashboard](http://192.168.10.214:9000/dashboard?id=swift)




For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).


