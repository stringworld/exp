/**
 * Created by zhouhua on 2016/12/20.
 */
import Vue from 'vue';
import VueRouter from 'vue-router';
import bus from 'src/event';
Vue.use(VueRouter);

import Hello from 'src/views/Hello';
import Login from 'src/views/login/login';
import forgetPwd from 'src/views/forgetPwd/forgetPwd';
import patientList from 'src/views/patientList/patientList';
import medicationRegimen from 'src/views/medicationRegimen';
import fluxDemo from 'src/views/fluxDemo';
import addPatient from 'src/views/addPatient/addPatient';

const routes = [{
        path: '/',
        redirect: '/login'
    },
    {
        name: 'hello',
        path: '/hello',
        meta: {
            title: '图文咨询',
            keepAlive: false
        },
        component: Hello
    },
    {
        name: 'login',
        path: '/login',
        meta: {
            title: '用药提醒',
            keepAlive: false
        },
        component: Login
    },
    {
        name: 'forgetpwd',
        path: '/forgetpwd',
        meta: {
            title: '忘记密码',
            keepAlive: false
        },
        component: forgetPwd
    },
    {
        name: 'patientlist',
        path: '/patientlist',
        meta: {
            title: '患者列表',
            keepAlive: false
        },
        component: patientList
    },
    {
        name: 'medicationRegimen',
        path: '/medication/regimen',
        meta: {
            title: '用药方案',
            keepAlive: true
        },
        component: medicationRegimen
    },
    {
        name: 'fluxDemo',
        path: '/fluxDemo',
        meta: {
            title: 'fluxDemo',
            keepAlive: true
        },
        component: fluxDemo
    },
    {
        name: 'addpatient',
        path: '/addpatient',
        meta: {
            title: '添加患者',
            keepAlive: false
        },
        component: addPatient
    }

];

const router = new VueRouter({
    // mode: 'history',
    routes
});

// 路由导航钩子，beforeEach，在路由进入前调用
router.beforeEach((to, from, next) => {
    bus.$emit('changeTitle', to.meta.title);
    // 继续路由导航
    next();
});



export default router;