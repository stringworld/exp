<template>
    <div class="bind-phone">
        <h1 class="login-title">用药提醒</h1>
        <div class="form-row">
            <input type="number" class="block-input" placeholder="手机号" v-model="phone" />
        </div>
        <div class="form-row">
            <input type="number" class="block-input" placeholder="密码" v-model="passworld" />
        </div>
        <p class="text-muted text-left">
            6~19位任意字符,区分大小写
        </p>
        <button type="button" class="form-row bind-btn" :disabled="!phoneValid || !passworldValid || waiting" @click="login">
            登录
        </button>
        <p class="text-muted text-right">
            忘记密码
        </p>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import './login.less';
</style>

<script type="text/javascript">
    import router from 'src/routes';
    import bus from 'src/event';
    import { MessageBox } from 'mint-ui';

    export default {
        data() {
            return {
                changeTitle: '用药查询',
                phone: '',
                passworld: '',
                // phoneValid: false,
                // passworldValid: false,
                counting: false,
                waiting: false
            }
        },
        created() {
            // bus.$emit('changeTitle',this.changeTitle);
        },
        computed: {
            phoneValid() {
                return this.validateMobile(this.phone);
            },
            passworldValid() {
                return this.validatePwd(this.passworld);
            },
            errorText() {
                if (this.phone || this.passworld) {
                    if (!this.phoneValid) {
                        return '请输入正确的手机号码';
                    }
                    if (!this.phone) {
                        return '请输入手机号码';
                    }
                    if (!this.passworld) {
                        return '请输入密码';
                    }
                    if (!this.passworldValid) {
                        return '请输入正确的验证码';
                    }
                    return '';
                }
            }
        },
        methods: {
            validateMobile(mobile = '') {
                return /^1[345789]\d{9}$/.test(mobile);
            },
            validatePwd(passworld = '') {
                return /^\d{4}$/.test(passworld);
            },
            login() {
                if (this.phoneValid && this.passworldValid && !this.waiting) {
                    this.waiting = true;
                    this.$http.get('/member/binding/', {
                        params: {
                            mobile: this.phone,
                            passworld: this.passworld
                        }
                    }).then(({data}) => {
                        this.waiting = false;
                        if (!data.code) {
                            this.code = '';
                        } else {
                            MessageBox('提示', data.errorMsg);
                        }
                    }, () => {
                        this.waiting = false;
                    });
                }
            }
        }
    }
</script>