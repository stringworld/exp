<template>
    <div class="medicationRegimen">
        {{count}}
        <button @click="add">add</button>
    </div>
</template>
<script type="text/javascript">
    export default {
        computed: {
            count() {
                return this.$store.state.medicationRegimen.count
            }
        },
        methods: {
            add() {
                this.$store.dispatch('medicationRegimen/ADD', 10)
            }
        }
    }

</script>


<style lang="less" scoped rel="stylesheet/less">
    
</style>