<template>
    <div class="medicationRegimen">
        <ul class="medicationDetail">
            <li>
                <i class="font-dark">药品名称</i>
                <em class="font-subdark">{{drugName}}</em>
            </li>
            <li>
                <i class="font-dark">提醒时间</i>
                <em class="font-subdark">{{emindTime}}</em>
            </li>
            <li class="choose-week">
                <span>周一</span>
                <span>周二</span>
                <span>周三</span>
                <span>周四</span>
                <span>周五</span>
                <span>周六</span>
                <span>周日</span>
                <span>每日</span>
            </li>
            <li>
                <i>用药时间与剂量</i>
            </li>
            <li>
                <input type="button" class="add-time-dosage" value="添加时间及剂量">
            </li>
            <li class="remark">
                <textarea placeholder="备注(选填)"></textarea>
            </li>
        </ul>
    </div>
</template>
<script type="text/javascript">
    export default {
        data() {
            return {
                drugName: '请选择',
                emindTime: '请选择'
            }
        }
    }

</script>


<style lang="less" scoped rel="stylesheet/less">
    .medicationRegimen {
        .font-dark {
            color: #53535c;
        }
        .font-subdark {
            color: #83838f;
        }
        .medicationDetail {
            li {
                margin-left: 10px;
                line-height: 40px;
                border-top: 1px solid #EBEBF0;
                em {
                    position: absolute;
                    right: 15px;
                }
                &.choose-week {
                    overflow: hidden;
                    span {
                        text-align: center;
                        display: inline-block;
                        width: 70px;
                        border: 1px solid #FCB8BF;
                        border-radius: 10px;
                        line-height: 22px;
                        margin: 0 10px 0 0;
                        color: #FCB8BF;
                    }
                }
                .add-time-dosage {
                    width: 100%;
                    color: #FCB8BF;
                    text-align: center;
                }
                &.remark {
                    width: 100%;
                    textarea {
                        resize: none;
                        width: 100%;
                        line-height: 40px;
                    }
                }
            }
        }
    }
</style>