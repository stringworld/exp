<template>
    <div class="add-patient-warp">
        <mt-header title="title" center>
            <router-link to="/" slot="left">
                <mt-button icon="back">返回</mt-button>
            </router-link>
            <mt-button slot="right"><span @click="goBack">保存</span></mt-button>
        </mt-header>
        <div class="patinent-message">
            <div class="item-box">
                <div class="item-box-hd">
                    <span class="add-icon">添加头像</span>
                </div>
                <div class="item-box-bd">
                    <div class="item-line-box"><input type="text" placeholder="姓名"></div>
                    <div class="item-line-box"><input type="tel" placeholder="手机号"></div>
                </div>
            </div>
            <div class="item-box">
                <div class="item-line-box"><input type="text" placeholder="地址"></div>
            </div>
            <div class="item-box">
                <div class="item-line-box"><input type="tel" placeholder="年龄"></div>
                <div class="item-line-box">性别
                    <label for="sex-man"><input type="radio" id="sex-man" name="sex" value="">男</label>
                    <label for="sex-gril"><input type="radio" id="sex-gril" name="sex" value="">女</label>
                </div>
            </div>
            <div class="item-box">
                <div class="item-line-box"><textarea type="text" placeholder="备注"></textarea></div>
            </div>
        </div>

    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import 'addPatient.less';
</style>
<script>
    import { Header, Actionsheet, Button } from 'mint-ui';
    export default {
        data() {
            return {
                title: '添加患者',
                actions: [{ name: '拍照', method: this.takingPhoto }, { name: '从相册中选择', method: this.openingAlbum }],
                sheetVisible: false
            }
        },
        methods: {
            goBack() {
                this.$router.go(-1);
            },
            openingAlbum(e) {
                console.log('opening album')
            },
            addPatient() {
                // alert('1');
                // this.openingAlbum();
                // let aPatient = document.getElementById('add-patient').click();
                // if (aPatient) {
                //     aPatient.click();
                // }
            },
            takingPhoto() {
                document.getElementById('mm').click();
                console.log('taking photo');
            },
            showVisible() {
                this.sheetVisible = true;
            },
            changeInput(value) {
                console.log(value);
            }
        }
    }
</script>