<template>
    <div>
        <div class="header">
            <div class="item-line-box">
                <span class="line-box-text search"><v-search v-on:change="changeInput"></v-search></span>
                <span class="line-box-text box-icon search-text" v-if="searching" @click="onSearch">搜索</span>
                <span class="line-box-text box-icon sex-man" v-else="!searching"></span>
            </div>
        </div>
        <div class="patient-wrap">


            <ul class="item-list" v-if="!searchResult.length">
                <li class="item-box" v-for="item in patientList">
                    <div class="item-box-hd"><img :src="item.img" :alt="item.name"></div>
                    <div class="item-box-bd">
                        <h4 class="item-box-title">
                            <span class="line-box-text">{{item.name}}</span>
                            <span class="line-box-text sex-icon" :class="{'sex-girl':item.sex,'sex-man':!item.sex}"></span>
                        </h4>

                    </div>
                </li>
            </ul>


            <ul class="item-list" v-else="searchResult.length">
                <li class="item-box" v-for="item in searchResult">
                    <div class="item-box-bd">
                        <h4 class="item-box-title">
                            <span class="line-box-text" v-html="item.value"></span></h4>
                    </div>
                </li>
            </ul>


        </div>
    </div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import 'patientList.less';
</style>

<script type="text/javascript">
    // <p class="item-box-label">{{item.address}}</p>
    import bus from 'src/event';
    import { Search, MessageBox } from 'mint-ui';


    export default {

        data() {
            return {
                value: '',
                searchResult: [],
                patientList: [],
                searching: false
            }
        },
        created() {
            this.getPatientList()
        },
        methods: {
            onSearch() {
                alert(this.value);
            },
            changeInput(value) {
                this.value = value;
                if (!value) {
                    this.searchResult = [];
                    this.searching = false;
                } else {
                    this.searching = true;
                    this.$http.get('/error.1', {
                        params: { value }
                    }).then(({data}) => {
                        console.log(data)
                        this.searchResult = data.data.map(item => ({
                            title: !item.title.indexOf(value) ? value : '',
                            value: item.title.replace(value, '<span style="color:red;">' + value + '</span>')
                        }));
                        // this.searchResult = data.data;
                    });
                }
            },
            getPatientList() {
                this.$http.get('/error', {
                    params: {}
                }).then(({data}) => {
                    console.log(data)
                    this.patientList = data.data;
                });
            }
        }
    }
</script>