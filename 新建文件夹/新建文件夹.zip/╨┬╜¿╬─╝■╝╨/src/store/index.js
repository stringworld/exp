import Vue from 'vue'
import Vuex from 'vuex'

import medicationRegimen from './modules/medicationRegimen'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
  modules: {
    medicationRegimen
  },
  strict: debug,
})