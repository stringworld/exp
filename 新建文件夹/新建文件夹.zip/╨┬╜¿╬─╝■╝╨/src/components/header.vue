<style lang="less" scoped>
	.header {
		position: relative;
		line-height: 40px;
		height: 40px;
		text-align: center;
		background: #eee;
		.item {
			position: absolute;
			height: 100%;
			top: 0;
			bottom: 0;
			z-index: 1;
		}
		.title{
			text-align: center;
			display: inline-block;
		}
		.left {
			left: 10px;
			padding-left: 15px;
			.item-input-inset{
				padding: 0;
			}
		}
		.right {
			right: 10px;
		}
		.arrow-cell-ft:after {
			content: " ";
			display: inline-block;
			height: 10px;
			width: 10px;
			border-width: 0 0 2px 2px;
			border-color: red;
			border-style: solid;
			transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
			position: absolute;
			top: 50%;
			margin-top: -6px;
			left: 2px;
		}
	}
</style>
<template>
	<header class="header">
		<div class="item left arrow-cell-ft">
			<slot name="left"></slot>
		</div>
		<div class="title" v-html="title"></div>
		<div class="item right">
			<slot name="right"></slot>
		</div>
	</header>
</template>
<script>
	export default {
		props: {
			title: {
				type: String,
				default: ''
			}
		}
	}
</script>