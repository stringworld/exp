import header from './header';
import search from './search';
export default { header, search }