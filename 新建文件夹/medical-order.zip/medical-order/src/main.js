// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import './assets/css/base.css'
import 'normalize.css';
import 'animate.css';
import 'vue-toast-mobile/lib/index.css';
import 'es6-promise/auto'; // polyfill for Promise. Axios maybe need this.
import Vue from 'vue';
import Mint from 'mint-ui';
import 'mint-ui/lib/style.css';
import axios from 'axios';
import App from './App';
import router from './routes/index';
import fastclick from 'fastclick';
import VueCookies from 'vue-cookies';
import store from './store'
// add Raven to monitor app status
// import Raven from 'raven-js';
// import RavenVue from 'raven-js/plugins/vue';
// Raven.config('https://96f082449c0841afb5445bd42d35106c@sentry.io/123576')
//     .addPlugin(RavenVue, Vue)
//     .install();

// remove click delays on touch devices.
fastclick.attach(document.body);

//api https://www.npmjs.com/package/vue-cookies
Vue.use(VueCookies);
Vue.use(Mint);

/* eslint-disable no-new */
Vue.prototype.$http = axios;

export default new Vue({
    el: '#app',
    store,
    router,
    ...App
});
