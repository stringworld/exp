<template>
    <h1>hello world</h1>
</template>
<style lang="less" scoped rel="stylesheet/less">
    h1 {
        text-align: center;
    }
</style>
<script type="text/javascript">
    export default {}
</script>
