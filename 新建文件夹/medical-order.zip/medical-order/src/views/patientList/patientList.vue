<template>
    <div class="patient-list">
        <div>
            <span style="display: inline-flex;min-width: 85%;vertical-align: middle;">
<mt-search v-model="value" cancel-text="搜索" placeholder="搜索" @input="changeInput"></mt-search>
</span>
<span><button class="button button-clear button-positive"> Cancel </button></span>
</div>


<ul class="item-list" v-if="!searchResult.length">
    <li class="item-box" v-for="item in patientList">
        <div class="item-box-hd"><img :src="item.img" :alt="item.name"></div>
        <div class="item-box-bd">
            <h4 class="item-box-title">
                <span class="title-text">{{item.name}}</span>
                <span class="sex-icon" :class="{'sex-girl':item.sex,'sex-man':!item.sex}"></span>
            </h4>
            <p class="item-box-label">{{item.address}}</p>
        </div>
    </li>
</ul>


<ul class="item-list" v-else="searchResult.length">
    <li class="item-box" v-for="item in searchResult">
        <div class="item-box-bd">
            <h4 class="item-box-title">
                <span class="title-text" style="color: red;" v-html="item.title"></span>
<span class="title-text" v-html="item.value"></span>
</h4>
</div>
</li>
</ul>


</div>
</template>
<style lang="less" scoped rel="stylesheet/less">
    @import 'patientList.less';
</style>

<script type="text/javascript">
    // <mt-cell v-else="searchResult.length" v-for="item in searchResult" :title="item.title" :class="{'red':item.title.indexOf(value)}"></mt-cell>
    import bus from 'src/event';
    import { Search, MessageBox } from 'mint-ui';
    export default {
        data() {
            return {
                value: '',
                searchResult: [],
                patientList: [],
                keywords: '',
                searching: false
            }
        },
        created() {
            this.getPatientList()
        },
        methods: {
            onSearch() {
                alert('dd')
            },

            changeInput() {
                console.log(this.value)
                if (!this.value) {
                    this.searchResult = [];
                } else {
                    this.$http.get('/error.1', {
                        params: { value: this.value }
                    }).then(({data}) => {
                        console.log(data)
                        this.searchResult = data.data.map((item) => ({
                            title: !item.title.indexOf(this.value) ? this.value : '',
                            value: (item.title).replace(this.value, '<span style="color:red;">' + this.value + '</span>')
                        }));
                        // this.searchResult = data.data;
                    });
                }
            },
            getPatientList() {
                this.$http.get('/error', {
                    params: {}
                }).then(({data}) => {
                    console.log(data)
                    this.patientList = data.data;
                });
            }
        }
    }
</script>