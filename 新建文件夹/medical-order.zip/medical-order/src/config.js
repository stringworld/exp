/**
 * Created by zhouhua on 2017/1/2.
 */
const config = {};
config.apiRoot = '';
config.apis = {
};

Object.keys(config.apis).forEach(key => {
    config.apis[key] = `${config.apiRoot}${config.apis[key]}`;
});

export default config;
