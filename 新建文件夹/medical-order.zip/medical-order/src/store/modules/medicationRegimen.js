import * as types from './types.js'
// initial state
// shape: [{ id, quantity }]
const state = {
    count: 1
}

// actions
const actions = {
    [types.ADD]({ commit },value) {
    setTimeout(() => {
      commit(types.ADD,value)
    }, 1000)
  }
}

// mutations
const mutations = {
    [types.ADD](state, payload) {
        state.count += payload
        console.log(state.count);
    }

}

export default {
    state,
    actions,
    mutations
}
