/**
 * Created by zhouhua on 2017/1/24.
 */
var gulp = require('gulp');
var sonarqubeScanner = require('sonarqube-scanner');


gulp.task('default', function(callback) {
    sonarqubeScanner({
        serverUrl: 'http://192.168.10.214:9000',
        token: '',
        options: {
            'sonar.sources': 'src, sonar_test',
            'sonar.exclusions': 'node_modules/**/*',
            'sonar.javascript.lcov.reportPaths': 'test/unit/coverage/lcov.info',
            'sonar.javascript.lcov.reportPath': 'test/unit/coverage/lcov.info',
            'sonar.coverage.exclusions': 'sonar_test/**/*'
        }
    }, callback);
});

