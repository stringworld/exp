#!/usr/bin/env bash

npm run test

rm -rf ./sonar_test

mkdir -p sonar_test

node test.js

gulp

