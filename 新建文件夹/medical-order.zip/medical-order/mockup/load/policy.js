var Mock = require('mockjs');
var data = function() {
	return Mock.mock({
		"code": 0,
		"data": {
			"isShowButton": false,
			"policy": {
				"abstractId": "106641",
				"created": 1471336569000,
				"disabled": false,
				"id": "1179",
				"idCard": "",
				"insuranceName": "用户不满意险",
				"insuranceType": "1",
				"memberId": "com.medishare.manis.domain.member.Patient_100063",
				"policyName": "周勇用户",
				"serviceId": "107753",
				"status": "0",
				"updated": 1471336569000
			}
		}
	})
}
module.exports = data;