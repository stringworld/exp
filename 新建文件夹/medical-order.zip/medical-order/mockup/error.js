var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        'data|1-10': [{
            'id|+1': 1,
            'img': 'http://avatar.csdn.net/A/2/3/3_u012987546.jpg',
            'name|+1': '@cfirst @clast',
            'address|+1': '@province @city @county',
            'sex|0-1': 1
        }]
    })
}
module.exports = data;