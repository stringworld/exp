var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": {
            "residentsName": "李四",
            "sex": "男",
            "age": 0,
            "area": "浦东新区",
            "address": "浦东新区",
            "committees": "某某居委",
            "signingDoctorName": "李四",
            "signingTime": "2016-12-11",
            "loginPhone": ["18720121524", "123456"],
            "doctorSex": "男",
            "doctorDepatment": "科室",
            "projectGoods": "擅长骨科",
            "hospitalInfo": "医院",
            "culturalDegree": "很好的医院，专注于骨科",
            "status": "1",
            "remark": "备注",
            "records": ["2016/10/14/122008_15900551545_8009_8009.wav"]
        }
    })
}
module.exports = data;