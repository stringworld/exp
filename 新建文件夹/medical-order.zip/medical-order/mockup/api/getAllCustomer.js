var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": [{
            "userId": "user0001",
            "pwd": "",
            "name": "daikaixain",
            "role": 0,
            "status": 1,
            "seatId": "8001",
            "checkInPwd": "",
            "groupId": 0,
            "created": 1479702853000
        }, {
            "userId": "user0003",
            "pwd": "",
            "name": "普通用户",
            "role": 0,
            "status": 1,
            "seatId": "8003",
            "checkInPwd": "",
            "groupId": 1,
            "created": 1480479047000
        }, {
            "userId": "user0004",
            "pwd": "",
            "name": "刘小刚",
            "role": 1,
            "status": 1,
            "seatId": "8004",
            "checkInPwd": "",
            "groupId": 1,
            "created": 1480485661000
        }]
    })
}
module.exports = data;