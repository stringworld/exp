var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "serialID": null,
        "data": {
            "abstractId": "111109",
            "state": "service",
            "diagnosisRecordId": '1235',
            "hasDiagnosisRecord": true,
            "patientInfo": {
                "name": "18803772992",
                "address": "上海上海市黄浦区南京东路街道龙泉园路居委会不存芥蒂你说你的打扮打扮笨蛋报道",
                "portrait": "http://192.168.10.215:8082/img/8986b71a-b693-4c08-8b17-bb95a2d473a5.png",
                "phone": "18803772992"
            },
            "doctorInfo": {
                "name": "007",
                "address": "上海市辖区普陀区宜川街道社区卫生服务中心",
                "portrait": "http://192.168.10.215:8082/img/dd8ceebf-808c-4644-8701-1dc7333f7049.png",
                "phone": "18803772992",
                "title": "主治医师",
                "memberId": "com.medishare.manis.domain.member.Doctor_100736",
                "id":"4225145"
            },
            "serviceInfo": {
                "price": "2664.0元",
                "name": "上门服务",
                "serviceDetail": [
                    "换药拆线",
                    "儿科上门"
                ]
            },
            "payInfo": {
                "method": "代金券",
                "orderPrice": "2664.0元",
                "actualPayAmount": "0.0元",
                "tradingTime": "2017-01-04 10:50"
            }
        },
        "errorMsg": null,
        "pager": null
    });
}
module.exports = data;