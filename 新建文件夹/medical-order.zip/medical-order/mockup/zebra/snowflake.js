/**
 * Created by zhouhua on 2017/1/10.
 */
var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        code: 0,
        data: {
            id: +new Date + ''
        }
    })
};
module.exports = data;
