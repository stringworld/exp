/**
 * Created by zhouhua on 2017/1/10.
 */
var Mock = require('mockjs');
var data = function () {
    return Mock.mock({
        "code": 0,
        "data": {
            "signature": "a4911d168cbc65831869fdf8d73b65be30bf9dd3",
            "appid": "wx637351d94226ec0d",
            "jsapi_ticket": "kgt8ON7yVITDhtdwci0qeRd9bZNDEVFM0G1vJnUekzO6QwxEeNlNkzaV0XHvf08D2UYnO9S0sLN7w_K5Gm2Jtw",
            "url": "http://wx.zhjun.top/ant/",
            "nonceStr": "9219307896804b5f83c0ae76838db3f4",
            "timestamp": "1484044989"
        }
    })
};
module.exports = data;
