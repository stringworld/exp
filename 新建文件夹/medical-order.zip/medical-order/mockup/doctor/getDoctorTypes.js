var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "data": {
            "doctorTypeList": [{
                    "doctorTypeId": "1",
                    "disable": false,
                    "doctorTypeName": "全科医生"
                },
                {
                    "doctorTypeId": "2",
                    "disable": false,
                    "doctorTypeName": "专科医生"
                },
                {
                    "doctorTypeId": "3",
                    "disable": false,
                    "doctorTypeName": "护士"
                },
                {
                    "doctorTypeId": "4",
                    "disable": true,
                    "doctorTypeName": "技师"
                },
                {
                    "doctorTypeId": "5",
                    "disable": true,
                    "doctorTypeName": "营养师"
                },
                {
                    "doctorTypeId": "6",
                    "disable": true,
                    "doctorTypeName": "心理咨询师"
                },
                {
                    "doctorTypeId": "7",
                    "disable": true,
                    "doctorTypeName": "公卫医生"
                },
                {
                    "doctorTypeId": "8",
                    "disable": true,
                    "doctorTypeName": "护工"
                }
            ]
        },
        "type": "JSONDoctor"
    });
};
module.exports = data;