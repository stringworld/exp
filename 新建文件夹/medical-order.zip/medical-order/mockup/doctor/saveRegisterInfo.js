var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        "isSuccess": true,
        "type": "JSONDoctorDetail",
        "data": {
            "nextPageRouter": "router://register?authText=全科医生执业证书&frontPageUrl=http://upyun.thedoc.cn/cdn/c_home_page/btn_yihushangmen.png&backPageUrl=http://upyun.thedoc.cn/cdn/c_home_page/img_shaicha.png"
        }
    });
};
module.exports = data;