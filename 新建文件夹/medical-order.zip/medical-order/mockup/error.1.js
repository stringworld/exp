var Mock = require('mockjs');
var data = function() {
    return Mock.mock({
        'data|1-10': [{
            'id|+1': 1,
            // 'title|+1': '@cfirst @clast',
            // 'value|+1': '@cfirst @clast'
            title: '张俊',
            value: '张俊'
        }]
    })
}
module.exports = data;