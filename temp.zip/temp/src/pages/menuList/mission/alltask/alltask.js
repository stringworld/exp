import uirouter from 'angular-ui-router';
import './alltask.less';


export default angular.module('alltask', [uirouter])

.name;