import uirouter from 'angular-ui-router';
import './mytask.less';


export default angular.module('mytask', [uirouter])

.name;