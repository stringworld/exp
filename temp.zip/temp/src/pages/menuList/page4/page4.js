import uirouter from 'angular-ui-router';
import routing from './page4.route';


export default angular.module('page4', [uirouter])
    .config(routing)

.name;