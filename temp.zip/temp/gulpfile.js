var gulp = require('gulp');
var rename = require("gulp-rename");
var webpack = require('webpack-stream');
var replace = require('gulp-replace');
var del = require('del');
var inject = require('gulp-inject-string');


// var cdn = 'http://192.168.3.248:8080/';
var cdn = '';



gulp.task('clean', function(cb) {

    return del([
        './dist'
    ], cb);
});


gulp.task('outputFile', ['clean'], function() {

    return gulp.src('./src/app.js')
        .pipe(webpack(require('./webpack.build.js')(cdn)))
        .pipe(gulp.dest('dist/'));
});


gulp.task('adaptBuilding', ['outputFile'], function() {
    var now = new Date;
    var version = now.getTime();
    //remove CDN and add version
    gulp.src('./dist/index.html')
        //.pipe(replace(cdn, ''))

    //.pipe(inject.after('<head>', '\n<info '
    //    + 'version='+'"'+version+'"'+' '
    //    + 'updata="['+cdn+'app.js,'+cdn+'app.css]"'
    //    + ' />')
    //)

    .pipe(gulp.dest('dist/'));


});

gulp.task('default', ['adaptBuilding'], function() {



});